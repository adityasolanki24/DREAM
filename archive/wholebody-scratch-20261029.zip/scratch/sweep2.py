import sys,math,numpy as np,mujoco
sys.path.insert(0,'.')
exec(open('scratch/sweep.py').read().split("rng=np.random")[0])
from collections import Counter
rng=np.random.default_rng(1)
cnt=Counter(); tot=Counter()
rows=[]
for t in range(80):
    hx,hy=rng.uniform(0.15,0.45,2); hz=rng.uniform(0.3,0.7); yaw=rng.uniform(-math.pi,math.pi)
    b=PerceivedBox((1.45+rng.uniform(-.1,.1),-0.25+rng.uniform(-.3,.3),hz),(hx,hy,hz),yaw)
    ids=pm.load_obstacles([b]); d=pm.data_at(q)
    for g in geoms:
        br=brute(d,g,b); mj=mujoco.mj_geomDistance(m,d,g,ids[0],1.0,ft)
        nm=m.body(int(m.geom_bodyid[g])).name
        tot[nm]+=1
        if (mj-br>0.02) or (mj<0 and br>0.03):
            cnt[nm]+=1; rows.append((round(yaw,2),round(hx,2),round(hy,2),nm,round(mj,3),round(br,3)))
print({k:(cnt[k],tot[k]) for k in tot})
for r in rows[:12]: print(r)
