exec(open('scratch/tq3.py').read().split("for plan0 in res.plans[:2]:")[0])
from dream.robot.g1_correction import correct_reach
from dream.robot.g1_rollout import _Meter
plan0=res.plans[0]
n=-np.array(ax); pre_pt=ptar+0.06*n
plan=pl.retarget(plan0,pre_pt,boxes,approach_axis=ax)
model=build_rollout_model(boxes)
env=G1MobileEnv(model,np.random.default_rng(0),head_camera=None); env.reset(*plan.stance); env.localise(plan.stance)
be=WBCBackend(env,WBCLocomotion.from_cache(),caps)
settle(be)
sup=WholeBodySupervisor(pl.pm,None,(plan.arm,tuple(pre_pt)))
rep=be.execute(plan.target,monitor=sup)
print('exec stops',rep.stops)
corr=correct_reach(be,sup,pl,plan,lambda: pre_pt,boxes,tolerance=0.015,approach_axis=ax)
for it in corr.iterations: print({k:(round(v,3) if isinstance(v,float) else v) for k,v in it.items() if k not in ('hand','target')})
print('stops',[(s.reason,s.detail) for s in corr.stops])
tr=[r for r in sup.trace]
import collections
print('peak ratio',max(r['torque_ratio'] for r in tr), 'joint',sup.joint_names[max(tr,key=lambda r:r['torque_ratio'])['torque_joint']])
