# DREAM web UI v3 restyle: owner's specification (verbatim, 28 Oct 2026)

## Visual reference (added by the owner afterwards): handoff/ui_v3_reference.png

The owner supplied a mockup ("Nova" console) as a guide: "somewhat like this, but adapt to our
system". The planner's ruling on how to use it:

ADOPT (visual language):
- light warm off-white page with white rounded cards and generous gaps;
- small uppercase eyebrow labels ("MISSION", "INTERRUPT · RUNNING NOW");
- soft pill chips in the header;
- pill buttons top right;
- the task list with round status checkboxes and the current task in a tinted rounded block with
  its sub-steps;
- the amber-tinted interrupt card with explanatory copy;
- the composer as a rounded pill with a dark circular send button;
- the camera inside a rounded card with a small caption pill;
- the graph with rounded pill nodes, thin curved edges and one highlighted node;
- a rounded map card;
- an "Activity" card listing recent events with relative time.

Mapping onto our structure (keep spec item 1):
- The Overview view may use this three-column feel: task card plus list, camera with the observed
  graph or objects, map plus activity. The sidebar, top bar, desktop chat column and the phone tab
  bar stay as the spec says.

DO NOT COPY (no honest data source in our API, or forbidden by the spec):
- "Take over" (teleoperation, forbidden). "Stop" becomes our Cancel, which acts at a safe point.
- Battery %, link strength or ms, "Live · 1080p", camera tabs for left hand or rear (we only have
  the head camera, updated when a tool observes; show the frame age instead).
- Detection confidence numbers on boxes; bounding boxes are not in the snapshot.
- Task progress bars, "2 of 5 tasks", "about 26 min left" (no ETA or progress data).
- Scene-graph relations "in / on / has" (no relation data: objects are a flat candidate list).
- The "Planned route" line (we have no planned path; the trail only if the data supports it).
- "Nova resumes Load dishwasher on its own": allowed only for a task paused BY INTERRUPT
  (resume='auto', which does resume automatically per scheduler.py). A user-paused task
  (resume='ask') must say it is waiting for Resume.
- Floor selector.
Where the mockup shows something we cannot back with data, leave it out. Do not fill it with
placeholders.

You are restyling and refining the DREAM web interface in web/ on the branch codex/phase1-agentic-interface. Read AGENTS.md first; it is binding.

GOAL
Make the interface look like a professional-grade, minimalist robot console with a soft, rounded, calm visual language, in two themes (light and dark), while keeping its current structure, data model and behaviour. This is a visual and UX pass, not a feature or backend rewrite.

HARD CONSTRAINTS (do not break)
- The interface stays non-teleoperating and goes only through TaskScheduler. No second orchestrator, no direct motor commands, no "take over" or joystick controls.
- Controls are only submit / pause / resume / cancel / reprioritise, and they act at safe action boundaries. Label them honestly: show "pausing..." and "cancelling..." states, never imply instant effect.
- Honest labels. Only show data the API actually returns. No invented ETAs, confidences, percentages or progress. "succeeded" must read "Runtime reports success". The task graph is the OBSERVED tool sequence, not a plan; label it so.
- Camera and map update only when a tool observes. Show the age of the camera frame (from camera.time_s vs robot_time_s) instead of implying a live stream.
- Keep the offline banner ("Connection lost. Showing the last data received; it is not live"), the rejected-token state, token in sessionStorage only, and the stream_id cursor reset. Never print or commit tokens.
- Do not modify backend Python unless a change is strictly required, and then say why before doing it.
- Do not touch C:\Users\24adi\DREAM-wholebody, and never delete or commit the unrelated untracked folders listed in the handoff.

THEMING (light and dark)
Build two complete themes on one token system.
- Define all colours, shadows and elevation as CSS variables in style.css. Light is defined under :root[data-theme="light"], dark under :root[data-theme="dark"]. No component may hard-code a colour; everything reads a token. Include tokens for: page, card, raised, hairline, text-primary, text-secondary, text-disabled, accent (active/running), amber (interrupt/paused), danger (cancel/failure), success label, focus ring, graph edge, graph node, dot grid, camera frame backdrop, and map colours (unknown, free, occupied, robot, trail).
- Default: follow prefers-color-scheme. Add a theme control (System / Light / Dark) in the existing settings menu. Persist the choice in localStorage under a non-sensitive key such as dream-theme (this is not the token; the token stays in sessionStorage only). Apply the theme before first paint (a tiny inline script in layout) so there is no flash of the wrong theme, and make sure it works with the static export (DREAM_EXPORT=1).
- Light palette: warm off-white page, white cards, warm grey hairlines, near-black text, one soft green-teal accent, amber for interrupt/paused, muted red for cancel/failure only.
- Dark palette: keep the existing neutral dark palette from the Orbit-based style (neutral greys, Inter, hairline borders, dot grid), softened and re-tokenised. Same accent hues, adjusted in lightness so they read correctly on dark.
- Both themes meet 4.5:1 for text and 3:1 for UI boundaries and focus rings. State is never conveyed by colour alone; pair it with an icon or text label. Verify contrast of every state pill and map/graph colour in BOTH themes and fix any failures.
- Camera frames, the map canvas, the React Flow graph (nodes, edges, background, minimap if present) and the Radix dialogs, dropdowns, tooltips and tabs must all follow the active theme. Set color-scheme appropriately so scrollbars and form controls match.

DESIGN DIRECTION (applies to both themes)
Warm minimalism in the spirit of Notion and Linear: generous spacing, hairline borders, very soft shadows, no gradient washes, no neon.
- Radii: 12px controls, 20px cards and panels, 28px large surfaces (camera, map, composer), 999px pills, chips and icon buttons. Nothing square-cornered except hairline dividers.
- Surfaces: three elevation levels only (page, card, raised), separated by 1px hairlines and one subtle shadow. In dark theme use hairlines and slight lightness steps instead of shadows. No nested cards inside cards.
- Spacing scale: 4/8/12/16/24/32. Cards use 20-24px padding.
- Motion: 150-200ms ease for hover and state changes, no springy or bouncy effects, respect prefers-reduced-motion. Theme switching should not animate heavy transitions.
- Minimum 44px touch targets, visible focus rings, real buttons, aria-labels on icon-only controls.

WHAT TO CHANGE (keep the existing component split in components.tsx)
1. Layout shell: keep sidebar (Overview / Activity / World / Memory), top bar, main area, right chat column on desktop, and the bottom tab bar (Chat / Robot / Task / Memory) at 850px or narrower. Soften the shell: floating rounded panels with a gap between them instead of edge-to-edge bordered columns.
2. Task strip and TaskPanel: a rounded "current task" card with a clear state pill (queued, running, suspended, succeeded, failed, cancelled), Pause / Resume / Cancel as pill buttons, and a visible "waiting for next safe point" state. Show queued and suspended tasks below it as a calm, ordered list with priority editable.
3. Interrupt and resume: FIRST read dream/runtime/scheduler.py and its tests to determine exactly what happens to a suspended task when a higher-priority task finishes (does it resume automatically, or only on an explicit resume?). Then make the UI state exactly that truth, with an amber "paused for interrupt" treatment on the suspended task and the same copy in the chat thread. Do not claim automatic resume unless the code does it.
4. Execution graph (React Flow): soft rounded pill nodes, thin low-contrast edges, subtle dot-grid background, current step highlighted, failed step marked with icon plus text. Keep it labelled as the observed tool sequence. Themed via tokens.
5. Camera view: large rounded frame, a small pill overlay with "last observed Ns ago" and the tool that produced it, and a calm empty state when there is no frame yet.
6. Map: a clean floor-plan feel (soft free space, muted unknown area, clear occupied cells, a robot pose marker with heading, and a trail only if the data supports it). Keep the "oracle-assisted odometry" label visible but quiet. Map colours come from tokens so both themes look right. Keep worldToPixel in map.mjs correct; add or extend tests there if you change geometry.
7. Objects / scene view: the snapshot only has a flat list of session object candidates, with no relations. Render them as rounded chips or small nodes with colour, id and position. Do NOT invent relations such as "on" or "in". Leave a clearly marked extension point for relations if a backend source is added later.
8. Chat: keep per-task threads with tool rows, example chips, provider label, draft preserved on failure and voice input. Restyle the composer as a large rounded pill with a circular send button; tool rows become compact rounded rows with status icons.
9. States: idle, connecting, online, offline, unauthorised and empty states all get designed treatments, not placeholder text, and must look correct in both themes.

DELIVERY
- Work in small commits with clear messages. Do not commit anything under results/ except new screenshots you intend to keep.
- Run, and report the output of: cd web && npm test, npx tsc --noEmit, npm run build:export. Do not claim a check passed if you did not run it.
- Re-run web/interface-e2e.cjs and capture screenshots at 1440x900 and 390x844, in BOTH light and dark, for: online with a running task, suspended task, offline banner, unauthorised, and the empty state. Save under results/phase1_interface/screenshots/ with a v3-light- or v3-dark- prefix.
- Add or extend a test that the theme token blocks define the same set of variables for light and dark, so a missing token in one theme fails the build.
- Finish with a short summary: what changed, what you deliberately did not change, anything in the doc or code that contradicted these instructions, and any limits you found (for example features the UI cannot truthfully show with the current API).
- If something here conflicts with AGENTS.md or the code, stop and ask rather than guess.
