import sys,math,numpy as np,mujoco,json
sys.path.insert(0,'.')
from dream.robot.g1_posture import *
pm=PlanningModel(); m=pm.model
c=(1.72,-0.34,0.676); H=(0.199,0.436,0.676); yaw=2.68
reps={'A':PerceivedBox(c,H,yaw),'B':PerceivedBox(c,(H[1],H[0],H[2]),yaw-math.pi/2)}
q=pm.q_nominal.copy(); q[0]=1.094; q[1]=-0.253
ft=np.zeros(6)
for k,b in reps.items():
    ids=pm.load_obstacles([b]); g=ids[0]
    d=pm.data_at(q)  # fresh after load
    row=[]
    for gg in pm.hand_geoms['right'][:5]+pm.hand_geoms['left'][:3]:
        row.append(round(mujoco.mj_geomDistance(m,d,gg,g,1.0,ft),4))
    print(k,row, 'geom_xpos',np.round(d.geom_xpos[g],3), m.geom_rbound[g])
