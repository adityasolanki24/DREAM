p='dream/robot/g1_posture.py'
s=open(p,newline='').read()
assert '\r\n' in s
s=s.replace('\r\n','\n')
def rep(a,b,cnt=1):
    global s
    assert s.count(a)==cnt,(a,s.count(a))
    s=s.replace(a,b)

# 1. obstacle slots: bounding volumes follow the size; canonical local frame
rep('''        m.geom_pos[self.slot_geoms] = FAR
        used = []
        for gid, b in zip(self.slot_geoms, boxes, strict=False):
            m.geom_pos[gid] = b.center
            m.geom_size[gid] = np.asarray(b.half_extents) + PERCEPTION_MARGIN
            m.geom_quat[gid] = [math.cos(b.yaw / 2), 0, 0, math.sin(b.yaw / 2)]
            used.append(gid)
        return used
''','''        m.geom_pos[self.slot_geoms] = FAR
        m.geom_size[self.slot_geoms] = 0.1
        m.geom_rbound[self.slot_geoms] = math.sqrt(3) * 0.1
        m.geom_aabb[self.slot_geoms] = [0.0, 0.0, 0.0, 0.1, 0.1, 0.1]
        used = []
        for gid, b in zip(self.slot_geoms, boxes, strict=False):
            half, yaw = canonical_box(b.half_extents, b.yaw)
            m.geom_pos[gid] = b.center
            m.geom_size[gid] = np.asarray(half) + PERCEPTION_MARGIN
            m.geom_quat[gid] = [math.cos(yaw / 2), 0, 0, math.sin(yaw / 2)]
            # MuJoCo does not refresh the bounding volumes when a size is edited at run time
            m.geom_rbound[gid] = float(np.linalg.norm(m.geom_size[gid]))
            m.geom_aabb[gid] = [0.0, 0.0, 0.0, *m.geom_size[gid]]
            used.append(gid)
        return used
''')
rep('''# ---------------------------------------------------------------------------------------------
# Geometry helpers

''','''# ---------------------------------------------------------------------------------------------
# Geometry helpers


def canonical_box(half, yaw: float) -> tuple[tuple[float, float, float], float]:
    """The same box with its shorter horizontal half extent along local x.

    mj_geomDistance between the robot's convex meshes and a box returned DIFFERENT clearances for
    the same box described with x and y swapped (and the yaw turned a quarter circle): measured on
    W5 held-out s5008/5009/5010/5020, where the perceived fixture (width first) produced
    zero-candidate plans and the identical box depth-first (the scene's convention) produced 13-17
    (H3 diagnosis, experiments/g1_reach_h3_diagnosis.py). One convention removes the dependence."""
    hx, hy, hz = (float(v) for v in half)
    if hx <= hy:
        return (hx, hy, hz), float(yaw)
    return (hy, hx, hz), float(wrap(yaw + math.pi / 2))

''')

# 2. approach axis is a preference: relax it per candidate, rank by its error
rep('W_RESIDUAL = 0.5  # per hand-tolerance of residual\n','W_RESIDUAL = 0.5  # per hand-tolerance of residual\nW_AXIS = 0.5  # per rad between the finger direction and the preferred approach axis\n')
rep('    def evaluate(self, q, stance, arm, target, boxes_regular=(), boxes_touch=()):\n','    def evaluate(\n        self, q, stance, arm, target, boxes_regular=(), boxes_touch=(), approach_axis=None\n    ):\n')
rep('''            "pelvis_tilt": float(math.acos(np.clip(z_pelvis, -1, 1))),
        }
''','''            "pelvis_tilt": float(math.acos(np.clip(z_pelvis, -1, 1))),
            "axis_error": 0.0,
        }
        if approach_axis is not None:
            want = np.asarray(approach_axis, float)
            finger = d.site_xmat[m.site(f"{arm}_grip").id].reshape(3, 3)[:, 0]
            cosine = float(finger @ want / np.linalg.norm(want))
            metrics["axis_error"] = float(math.acos(np.clip(cosine, -1, 1)))
''')
rep('            + W_RESIDUAL * m["hand_residual"] / HAND_TOLERANCE\n','            + W_RESIDUAL * m["hand_residual"] / HAND_TOLERANCE\n            + W_AXIS * m.get("axis_error", 0.0)\n')
# plan loop
rep('''                metrics, rpy, reasons = self.evaluate(q, stance, arm, target, regular, touch)
                walk = self._walk(robot_pose, stance)
''','''                metrics, rpy, reasons = self.evaluate(
                    q, stance, arm, target, regular, touch, approach_axis
                )
                metrics["axis_relaxed"] = 0.0
                if reasons and approach_axis is not None:
                    # The approach axis is a preference, not a requirement: a candidate that
                    # only fails because of it is tried again without it (H3: low targets).
                    q2 = self._ik(self._q_start(stance), stance, arm, target, None, limits)
                    if q2 is not None:
                        m2, rpy2, reasons2 = self.evaluate(
                            q2, stance, arm, target, regular, touch, approach_axis
                        )
                        if not reasons2:
                            q, metrics, rpy, reasons = q2, m2, rpy2, reasons2
                            metrics["axis_relaxed"] = 1.0
                walk = self._walk(robot_pose, stance)
''')
# retarget: same relaxation
rep('''        metrics, rpy, reasons = self.evaluate(q, plan.stance, plan.arm, pt, regular, touch)
        if reasons:
            return None
''','''        metrics, rpy, reasons = self.evaluate(
            q, plan.stance, plan.arm, pt, regular, touch, approach_axis
        )
        if reasons and approach_axis is not None:
            q = self.refine(
                plan.target.q, plan.stance, plan.arm, pt, boxes, None, iterations=iterations,
                hold_waist=True,
            )
            if q is None:
                return None
            metrics, rpy, reasons = self.evaluate(
                q, plan.stance, plan.arm, pt, regular, touch, approach_axis
            )
        if reasons:
            return None
''')
open(p,'w',newline='').write(s.replace('\n','\r\n'))
