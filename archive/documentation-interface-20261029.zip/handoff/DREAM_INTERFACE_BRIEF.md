# DREAM agent interface and tooling: how it works today (28 Oct 2026)

Copy everything below the line into another AI agent's context. The facts come from reading the code
at `codex/phase1-agentic-interface@5a353bf` (pushed to origin), plus the uncommitted files listed in section 9.

---

## 1. One-paragraph summary

DREAM is a robot-agent project (Unitree G1 humanoid, simulated in MuJoCo) with a Python runtime and a
web interface. A user types or speaks a goal in the web UI. The UI POSTs the goal to an authenticated
local HTTP API (`dream/runtime/phone_api.py`). The API puts the goal on a persistent SQLite
`TaskScheduler` queue, and the scheduler runs each task through DREAM's existing `TaskAgent` loop
(observe, plan one action, execute a typed tool, verify, repeat) over the mobile robot toolbox.
Every scheduler/agent event goes into an in-memory event log. The API serves that log raw
(`/events`) and translated into AG-UI events (`/ag-ui/events`), together with a polled
`/snapshot` holding the camera frame, map, objects, task graph and history. The UI polls every 1.2 s
and renders it. There is **no second orchestrator, no teleoperation and no direct motor command**
anywhere in the interface path. Control is only submit / pause / resume / cancel / reprioritise, and
those take effect at safe action boundaries.

```
Browser (web/, Next.js static export or dev server)
   |  Bearer token, JSON, polling 1.2 s online / 3.5 s offline
   v
PhoneAPI (stdlib http.server, 127.0.0.1:8765)  -- serves web/out/ at "/"
   |  submit/pause/resume/cancel/priority        ^ notify(kind, data) events
   v                                              |
TaskScheduler (SQLite queue, safe preemption) ----+
   |  run_task(task, history, preempt, cancel)
   v
TaskAgent (dream/runtime/agent.py)  -- planner.next_action() -> ToolCall | Finish
   |                                     planner = PlacePlanner | RoomSearchPlanner (structured, default)
   v                                               | MobileModelPlanner (Qwen or ChatGPT VLM)
MobileToolbox (dream/tools/mobile.py): look_around, go_to, approach, inspect, observe_scene, ...
   v
G1MobileBase + NVIDIA Decoupled WBC (balance/walk) in MuJoCo room scene (dream/sim/*)
```

## 2. Running it

```powershell
# from the repo root C:\Users\24adi\OneDrive\DREAM, venv at .venv
Set-Location web; npm ci; npm run build:export; Set-Location ..
.venv/Scripts/python.exe -m experiments.phase1_interface --seed 4100
# open http://127.0.0.1:8765/ and paste the token from %LOCALAPPDATA%\DREAM\phone_token
```

- Startup takes about 45 s while the MuJoCo G1 loads. The server prints its URL and the token-file path.
- Dev mode: run `cd web && npm run dev`. `next.config.mjs` rewrites `/status /tasks /tasks/* /snapshot /events
  /ag-ui/* /memory` to `DREAM_BACKEND_URL` (default `http://127.0.0.1:8765`), so the browser stays
  same-origin.
- `npm run build:export` sets `DREAM_EXPORT=1` and produces the static site `web/out`, which PhoneAPI
  serves at `/`, `/_next/*` and `/assets/*`. Without `web/out`, `/` serves a tiny fallback HTML page.
- Backend flags (`experiments/phase1_interface.py`):
  - `--seed` (room layout);
  - `--port` (default 8765);
  - `--store DIR` (SQLite task store, default `%LOCALAPPDATA%\DREAM\phase1\tasks-<provider>.sqlite`);
  - `--memory PATH` (existing HomeMemory SQLite, opened **read-only**);
  - `--provider structured|qwen|openai_chatgpt_plan`;
  - `--qwen-url` (OpenAI-compatible Qwen server; key in env `DREAM_QWEN_KEY`);
  - `--openai-token-file` and `--openai-model` (ChatGPT plan backend).
- Tests:
  - `cd web && npm test` runs 9 node tests: `feed`, `map`, `connection`.
  - `npx tsc --noEmit` type-checks.
  - `web/interface-e2e.cjs` is a headless-Edge end-to-end script (Playwright-core lives outside the
    repo in `C:\Users\24adi\.cache\dream-phase1\shots`).
  - Backend: `pytest tests/test_phone_api.py tests/test_scheduler.py tests/test_mobile_model.py`.

## 3. What tasks it accepts (important: not open natural language yet)

- **structured provider (default, not an LLM):** `dream/tools/goals.py::parse_goal`. The mobile
  session accepts only `inspect cabinet` (an `Inspect` goal, solved by
  `Budgeted(RoomSearchPlanner("gain"), base, 240 s)`) and `goto <place>` (a `GoToPlace` goal, solved by
  `PlacePlanner`). The only place defined is `entrance` (origin). Anything else returns HTTP 422 with
  a clear error, which the chat shows.
- **qwen / openai_chatgpt_plan:** only `inspect cabinet`. Each TaskAgent step makes one model
  decision through `dream/runtime/mobile_model.py::MobileModelPlanner`:
  - The model sees: the instruction, the bound goal, the observation (candidates, viewpoints,
    frontiers), the verifier verdict, history, and the latest head-camera RGB frame.
  - Its tools (`SCHEMAS`):
    - `look_around()`;
    - `approach(candidate:int, side:int)`;
    - `inspect(candidate:int)`;
    - `explore_frontier(index:int)`, which becomes `go_to(x, y)`;
    - `finish(success:bool, reason:str)`.
  - It **fails closed**:
    - unparsable output, unknown tools, or IDs not in the current observation end the task with `Finish(False, ...)`;
    - `finish(success=true)` is rejected unless the verifier verdict is satisfied.
- The scheduler task store is per provider, and a POST with a `provider` different from the
  configured one is rejected (422).

## 4. HTTP API (`dream/runtime/phone_api.py`)

- **Auth:**
  - Every non-static request needs `Authorization: Bearer <token>`, compared in constant time.
  - The token is generated once (`secrets.token_urlsafe(32)`) into `%LOCALAPPDATA%\DREAM\phone_token`. It is never logged; request logging is disabled.
  - The server binds to 127.0.0.1. Phone access needs a private tunnel/VPN; never expose it publicly.
  - Bodies are limited to 64 KB and must be JSON objects.

| method | path | returns |
|---|---|---|
| GET | `/status` | `{running: task_id or null, robot_time_s, odometry, stop_reason}` |
| GET | `/tasks` | list of Task (see types) |
| GET | `/snapshot` | Snapshot (section 5) |
| GET | `/events?after=n` | raw scheduler/agent events `{n, kind, id, ...}` (last 2000 kept) |
| GET | `/ag-ui/events?after=n` | `{cursor, events: [AG-UI events], stream_id}` |
| GET | `/memory?label=x` | memory query if configured |
| POST | `/tasks` `{text, priority?, provider?}` | 201 `{id}`; 400 on bad input (text 1-500 chars, priority int in [-1000,1000]); 422 if unparsable or wrong provider |
| POST | `/tasks/{id}/cancel` | `{result}`, e.g. "cancelling" (at a safe boundary) or cancelled-before-running |
| POST | `/tasks/{id}/pause` | `{result}`, e.g. "pausing"; the task becomes `suspended` at the next action boundary |
| POST | `/tasks/{id}/resume` | `{result: "resume allowed"}` |
| POST | `/tasks/{id}/priority` `{priority}` | `{result: "priority set"}` |

- **Task states:** `queued`, `running`, `suspended`, `succeeded`, `failed`, `cancelled`.
- **Preemption and safety:**
  - `succeeded` is the **runtime's own claim** (`ep.success_claimed`), not an independent physical verification. The UI labels it "Runtime reports success".
  - Cancellation wins over everything.
  - TaskAgent re-checks cancel/preempt after the planner returns, so a slow planner cannot dispatch one more tool after a stop. This is tested by `test_cancellation_during_planning_never_dispatches_a_tool_or_claims_success`.
  - A robot protective stop ends the task ("operator reset needed").
- **Event kinds (raw):**
  - from the scheduler: `accepted`, `started`, `resumed`, `succeeded`, `failed`, `cancelled`, `suspended`;
  - from TaskAgent: `action {tool, args}`, `result {status, message}`, `finish`.
- **AG-UI translation (`ag_ui_events`):**
  - `started`/`resumed` become `RUN_STARTED {threadId: task_id, runId: "<task>-<n>"}`.
  - `action` becomes `TOOL_CALL_START` + `TOOL_CALL_ARGS` (JSON args) + `TOOL_CALL_END`, with `toolCallId: "<task>-<n>"`.
  - `result` becomes `TOOL_CALL_RESULT`, with content JSON `{status, message}`.
  - `succeeded`/`cancelled`/`suspended` become `RUN_FINISHED {result: {state, reason}}`.
  - `failed` becomes `RUN_ERROR`.
  - Anything else becomes `CUSTOM {name: "dream.scheduler", value: raw event}`.
  - Event numbers restart when the backend restarts. `stream_id` changes on every backend start, and the UI resets its cursor and feed when the stream changes.

## 5. Snapshot (`experiments/phase1_interface.py::make_snapshot`)

- `environment`: "MuJoCo simulation (Unitree G1)".
- `provider`, `provider_label`, `provider_choices`.
- Robot state: `robot_time_s`, `odometry` ([x, y, yaw], **oracle-assisted**), `stop_reason`.
- `camera`: the last head-camera RGB frame as a PNG data URL plus `time_s`. It **only updates when a tool
  observes**; there is no continuous video stream.
- `map`: the occupancy grid cropped to known cells (0 unknown / 1 free / 2 occupied), with `resolution_m`,
  `origin_m`, `axes: "cells[x][y]"` and `odometry: "oracle-assisted"`.
- `objects`: this session's object candidates `{id, color, position, extent, views}`. These are
  session observations, not persistent memory.
- `persistent_memory`: read-only HomeMemory last sightings (`--memory`), or null. It is labelled "last recorded
  sightings; current state not assessed".
- `task_graph`: an **observed execution sequence** (tool calls in order, linear edges) for the running or
  latest task. It is not a planned graph.
- `tool_executions`: the raw action/result events.
- `outcome`: the latest finished task's state and reason.
- `history`: all tasks.

## 6. Web UI (`web/app/`)

- **Stack:**
  - Next.js 15.5 (App Router, client component), React 19, TypeScript;
  - `@ag-ui/core` 1.0.3, types only, so there is no runtime event validation;
  - `@xyflow/react` (React Flow) for the execution graph;
  - Radix UI (dialog, dropdown, tabs, tooltip);
  - lucide-react icons.
  - CopilotKit is **not** integrated: its open-source route needs a separate Node runtime bridge.
  - Styling follows the owner's Orbit frontend (`prxptn/Orbit-Frontend`, revision `f73adf3`): neutral
    dark palette, Inter, hairline borders, dot grid.
- **Files:**
  - `page.tsx`: state, polling loop, connect/submit/act, layout.
  - `components.tsx`: Panel, Empty, ConnectionBadge, ConnectCard, Chat (with voice), RobotView, MapPanel, TaskPanel (React Flow graph and tool rows), MemoryPanel, Toasts, NotifyButton.
  - `feed.mjs`: a pure reducer from AG-UI events to per-task threads, tools and notices.
  - `connection.mjs`: a poll gate that drops stale responses after a reconnect, plus fetch with an 8 s timeout.
  - `map.mjs`: `worldToPixel`.
  - `types.ts`: the API shapes.
  - `style.css`.
- **Desktop (wider than 850 px):**
  - a left sidebar with Overview / Activity / World / Memory;
  - a top bar with a breadcrumb, connection badge, notification toggle and settings menu ("Change access token", notifications);
  - a main area with the camera/map tabs and a current-task strip with Pause / Resume / Cancel buttons and "View activity →";
  - a right-hand conversation column for chat.
- **Phone (850 px or narrower):** a bottom tab bar with Chat / Robot / Task / Memory.
- **Connection states:**
  - `idle` / `connecting` / `online` / `offline` / `unauthorised`;
  - a ConnectCard for the token, which is kept in `sessionStorage` only;
  - a "Connection lost. Showing the last data received; it is not live" banner;
  - a rejected token stops polling.
- **Chat:**
  - shows each task as a thread with its tool rows (name, args summary, status, message), state label and the runtime's finish claim;
  - offers example chips (`inspect cabinet`, `goto entrance`);
  - shows the provider label and keeps the draft when sending fails;
  - has voice input through the browser Web Speech API when available, with error notes and typing as the fallback.
- **Notifications:**
  - in-app toasts: task started, tool failures, run end, failures;
  - optional OS notifications through the browser Notification API, after permission.
- Sizes tested: 1440x900 and 390x844 (headless Edge). Screenshots are in `results/phase1_interface/screenshots/`
  (committed: `v2-final-graph.png`, `v2-final-phone-chat.png`, `v2-final-phone-robot.png`,
  `v2-live-camera.png`; earlier ones are untracked). Receipts are `results/phase1_interface/v2-e2e-final.log`
  and `review/`.

## 7. VLM backends (all share `generate(messages, tools) -> text`, parsed by `dream/runtime/vlm.py::parse_tool_call`)

- **Qwen3-VL** (`dream/runtime/qwen.py`): an `OpenAICompatibleBackend` (HTTP server) or a local
  transformers model on the GPU, with optional extras `vlm`. It remains the selectable and offline fallback.
  The comparison checkpoint is now pinned. A GCP workload, `vlm-compare` in `cloud/launch.py`, runs the decision
  set on one capped L4 (estimated US$2.16; US$6 ceiling). Its startup bug was fixed in `a080cac`.
  **It has not run on the frozen set yet. There are no Qwen numbers for this comparison.**
- **ChatGPT plan** (`dream/runtime/openai_plan.py`, `dream/runtime/siwc_auth.py`):
  - The official "Sign in with ChatGPT" (SIWC) route: OIDC + PKCE with a dynamic client, scopes
    `openid profile email offline_access resource.invoke chatgpt.tokens.use.direct`, then
    `POST https://api.openai.com/v1/responses` (stream, `store:false`, bearer token).
  - Login: `python experiments/openai_plan_login.py` (browser, loopback `127.0.0.1:1455`).
  - Refresh: `python -m experiments.openai_plan_refresh <credential-file>` (serialized and atomic).
  - The credential lives outside Git in `%LOCALAPPDATA%\DREAM\openai-chatgpt-plan\<oaiapp_id>.json`.
  - TLS goes through the OS trust store (truststore) with a certifi fallback, and verification is always on.
  - Tools are sent as developer `additional_tools`. No `system` role is sent, and `temperature` /
    `max_output_tokens` are omitted (preview rules).
  - The plan quota is shared with the owner's own ChatGPT/Codex use, and limits are opaque.
- **Measured so far:** a frozen 11-decision set, MuJoCo G1 head-camera renders, answers pre-registered
  in `results/phase1_vlm_compare/decisions.json`.
  - `gpt-6-luna`, reasoning `none`: 11/11 valid tool calls and 6/11 correct (navigation 1/4, object
    identification 2/4, information gathering 3/3). The fixed `look_around` baseline scores 3/11. Latency was
    p50 3.9 s and max 5.5 s; 5,213 input and 213 output tokens. Results are in `results/phase1_gpt_luna_none_20261028/`.
  - Caveats: candidate proposals are ground-truth-assisted and positive candidates always have ID 0,
    so this is an **interface pilot, not a vision evaluation**.
  - `gpt-6.1-sol`: three earlier attempts failed on SSE stream parsing (a pipeline fault, now fixed). A canary
    gave a valid but wrong navigation call. The staged resume run (3 calls) is 0/3.
  - **Verdict: not decided.** GPT is not established as the primary VLM.

## 8. VoLoAgent (NVlabs) status

- Upstream is cloned outside the repo (`C:\Users\24adi\.cache\dream-phase1\VoLoAgent`, Apache-2.0), with its own
  env `voloenv`.
- It is a proxy around external services that are not released: RoboLab/Isaac eval client, VLA server,
  VLM endpoint, and a grasp server with GraspGen/SAM3/cuRobo/Molmo2.
- It is **Franka Panda only**: 7 joints plus a binary gripper, an 8-D action in 8-row chunks at 20 Hz. It has no G1, Dex3, SONIC or
  whole-body path.
- `dream/runtime/volo_contract.py` is a **non-actuating** contract adapter, tested by `tests/test_volo_contract.py` with
  upstream-recorded fixtures. `experiments/run_volo_passthrough_smoke.py` reproduces the official
  passthrough schema example against a mock policy only. No actuation mapping exists or is enabled.
- Recommendation so far: keep DREAM's Toolbox and TaskAgent; reuse VoLo's decision protocol and
  failure-monitor ideas behind typed DREAM tools; do not reuse its Franka-bound grasp/place executors.
  `docs/phase1/VOLOAGENT.md` is **not written yet**.

## 9. What changed since the 28 Oct ~00:30 Claude→Codex handoff

1. `b8e2948`, responsive agent workspace and restart-safe event connection:
   - the web app was committed (sidebar + phone tab bar, Radix UI, React Flow graph, voice, notifications);
   - `stream_id` was added to `/ag-ui/events`, with UI cursor reset on backend restart and the poll gate;
   - README sections, final screenshots and e2e receipts were added.
2. `a080cac`: fixed a broken shell line continuation in `cloud/vm_startup.sh` that stopped the VLM process
   from starting, with a regression test.
3. `5a353bf`:
   - the ChatGPT stream parser keeps completed tool items, rejects incomplete streams, and serialises credential rotation;
   - added `experiments/openai_plan_refresh.py`;
   - recorded the GPT-6 Luna pilot with honest caveats;
   - pinned the Qwen checkpoint;
   - added cloud provenance gates;
   - added the VoLo passthrough smoke against a mock policy.
4. The branch has been **pushed** (origin is at `5a353bf`).
5. Staged but uncommitted:
   - `experiments/summarize_vlm_comparison.py` and `tests/test_summarize_vlm_comparison.py`;
   - `results/phase1_gpt_resume_20261028/`, the Sol resume run: 3 calls, 0/3.
6. Untracked:
   - `handoff/`;
   - `tests/test_phase1_backends.py`;
   - `results/phase1_volo_resume/`;
   - older screenshots and logs in `results/phase1_interface/`;
   - `transcript.md` and unrelated older result folders. Never delete or commit those unrelated folders.

## 10. Known limitations (do not overstate)

- Goals are structured (`inspect cabinet`, `goto <place>`), not open natural language.
- Camera and map refresh only when a tool observes, and the UI polls rather than streams.
- Odometry is oracle-assisted, the environment is MuJoCo simulation only, and there is no real robot.
- "Succeeded" is the runtime's claim. The task graph is the observed tool sequence, not a plan.
- AG-UI events are not validated at runtime; CopilotKit is not used.
- OS notification delivery was not tested. Speech depends on the browser.
- Known unrelated test failure: `tests/test_isolation.py`, because `skills/g1_reach.py` imports mujoco.

## 11. Rules for any agent working on this

- Read `AGENTS.md` first; it is binding: no oracle data in decision code, no assisted grasps,
  freeze-before-evaluate, and honest labels.
- The interface must stay non-teleoperating and go through `TaskScheduler`. Never add a second orchestrator.
- Never print or commit tokens: `phone_token` and the SIWC credential stay outside the repo.
- Cloud work only through `cloud/launch.py` workloads: one session, US$6 ceiling, a deletion deadline, and the cost recorded in `isaac_ledger.json`.
- Laptop limits: each MuJoCo process takes about 7 GB of virtual memory, so run at most 2. Send background output to log files.
- Do not touch the other worktree `C:\Users\24adi\DREAM-wholebody` (branch `claude/wholebody-autonomy`).
