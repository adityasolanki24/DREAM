# DREAM Phase 1 handoff to Codex (28 Oct 2026)

Paste everything below the line into a new Codex session opened in `C:\Users\24adi\OneDrive\DREAM`.

---

You are continuing **DREAM Phase 1: agentic interface, GPT vision and VoLoAgent compatibility**.
You (Codex) started this phase, hit your usage limit, and a Claude Code session (Opus 5.5 planning,
Sonnet 5.5 workers) continued it. The owner then stopped all work on 28 Oct ~00:30 Sydney time so you
can finish it. Everything below was verified by the Claude planner unless marked "worker-reported".

## 0. Roles (binding, same as before)

You are the **planner and reviewer: GPT-6.1 Sol** (high reasoning for planning/review/decisions, medium for
routine supervision). Do not do the bulk work yourself. Delegate bounded tasks to workers:
**GPT-6.1 Terra (medium)** for implementation, running servers/experiments, commits; **GPT-6 Luna
(medium)** for read-only research, verification, docs review. Every brief is self-contained (repo,
branch, owned files, files not to touch, interpreter, steps, stop condition, report format). Workers own
disjoint files, commit only their own paths, never push, and escalate decisions to you. Verify every
worker report against git, files and outputs before telling the owner. Commit and push verified
milestones (owner's instruction for this phase).

## 1. The phase brief (owner's, condensed - still the target)

Only three objectives; implement and test, do not write another large plan. Do not expand into
whole-body control, SLAM or household benchmarks.

1. **Agentic web interface** for phone and laptop in Orbit's visual language (Next.js, React, TS,
   CopilotKit/AG-UI, React Flow where useful): chat task submission (voice where practical), live robot
   camera and status, active task graph/progress/tool executions/verified outcomes, spatial map,
   persistent object memory, task history, safe interruption/cancellation, real-time notifications,
   clear errors/loading/connection states. Fully autonomous robot: **no teleoperation controls**.
   Connect to DREAM's existing Python runtime (scheduler, phone API, TaskAgent, memory, telemetry) with
   typed tools and live events; **no second orchestrator**. Real data when connected; label demo or
   unavailable data. Test both screen sizes and main flows.
2. **ChatGPT as DREAM's VLM** via the official Sign in with ChatGPT route only (no Codex credentials,
   no endpoint scraping or browser automation). Verify auth, model availability, real image+text
   inference on DREAM camera images, structured tool selection, latency/errors/limits, compatibility
   with DREAM tools. Keep Qwen3-VL as a selectable fallback. Compare GPT vs Qwen on identical
   observations (navigation, object identification, information gathering). Verdict on GPT as primary
   high-level VLM. **Owner: use plan limits judiciously.**
3. **VoLoAgent (NVlabs/VoLoAgent) integration feasibility**: independent execution, G1+Dex3 support,
   GR00T/SONIC interfaces, typed DREAM tools, remaining incompatibilities; reproduce the smallest
   official example; minimal **non-actuating** adapter/contract test; never command the G1 through an
   unverified mapping; stop at a recommendation.

Deliverables: working web UI with mobile and desktop previews; real backend connection showing task
submission and live agent status; evidence-backed GPT vision test and Qwen comparison; VoLoAgent
compatibility test and recommendation; verified source changes, screenshots, concise setup docs.

## 2. Repository and environment

- Checkout `C:\Users\24adi\OneDrive\DREAM`, branch **`codex/phase1-agentic-interface`** (based on
  `claude/isaac-g1-kitchen@140fea1`). **Nothing on it is pushed yet.** Read `AGENTS.md` first (binding).
- Do not touch the other worktree `C:\Users\24adi\DREAM-wholebody` (branch `claude/wholebody-autonomy`;
  paused whole-body work with its own handoff in `handoff/CODEX_HANDOFF.md` there).
- Pre-existing untracked results (`results/compartment_experience_smoke/`, `results/demo/drawer_1x/`,
  `results/g1_autonomy_dev/...`, `results/g1_command_demo_mujoco/`, `results/g1_*_demo_video/`,
  `results/g1_relocalise_demo_smoke/`) and `transcript.md` are not Phase 1 work: never delete or commit
  them.
- Python: `C:\Users\24adi\OneDrive\DREAM\.venv\Scripts\python.exe`. Git Bash; chain
  `ruff check <paths> && pytest <focused tests> && git commit`. Run focused tests only.
- Disk: C: now has ~73 GB free (it was nearly full earlier). Still: log background output to files,
  print progress only, never arrays in loops; each MuJoCo process ~7 GB virtual memory, max 2 at once.
- Known unrelated failure: `tests/test_isolation.py` fails because `skills/g1_reach.py` imports mujoco.
- Caches outside the repo: Orbit clone `C:\Users\24adi\.cache\dream-phase1\Orbit-Frontend`
  (from GitHub `prxptn/Orbit-Frontend`); VoLoAgent clone `...\dream-phase1\VoLoAgent` (commit b4e6230);
  separate VoLo env `...\dream-phase1\voloenv`; Playwright-core in `...\dream-phase1\shots`; Edge at
  `C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`.

## 3. Commits on the branch (oldest first, all unpushed, verified present)

| commit | what |
|---|---|
| 82b11a3 | Scheduler safe pause, locked reads, cancellation wins; TaskAgent re-checks stop after the planner returns (fixes the race where a slow planner dispatched one more tool after a stop) |
| 095d782 | Phone API: snapshot, AG-UI event translation from scheduler events, static web root, input validation |
| ba5d547 | Interface bridge: mobile model planner (`dream/runtime/mobile_model.py`), snapshot builder, read-only HomeMemory (`experiments/phase1_interface.py`) |
| 9a9ea68 | SIWC sign-in (`dream/runtime/siwc_auth.py`, `experiments/openai_plan_login.py`), ChatGPT-plan Responses backend (`dream/runtime/openai_plan.py`), verified TLS (OS trust store via truststore, certifi fallback, verify always on), `tests/test_openai_plan_auth.py`, pyproject `openai-plan` extra |
| dbe3c51 | AG-UI run end carries the real outcome (RUN_ERROR for failures) |
| a5fe9f4 | Pre-registered 11-decision comparison set + frames (`results/phase1_vlm_compare/decisions.json`, `frames/`), generator `experiments/vlm_compare_frames.py` - committed before any inference |
| 5b9f5e2 | Comparison runner `experiments/vlm_compare.py` (backends gpt, qwen-local, qwen-http), GPT run JSON, `docs/phase1/GPT_VISION.md` |
| 874eb58 | Cloud: whitelisted `vlm-compare` workload (`cloud/launch.py`, `cloud/vm_startup.sh`, `experiments/configs/cloud_vlm_compare.json`, `tests/test_vlm_compare_cloud.py`); plan estimate US$2.16 / 45 min on one L4. **Never launched.** `tests/test_cloud.py` and `tests/test_g1_cloud.py` were not run to completion after this change - run them. |
| e8775ed | GPT_VISION note on the unlaunched Qwen workload |
| 5a8b44f | Snapshot labels its environment as MuJoCo simulation |
| 084568d | VoLoAgent non-actuating contract adapter `dream/runtime/volo_contract.py`, `tests/test_volo_contract.py`, upstream-recorded fixture `tests/fixtures/volo_upstream_messages.json`, recorder `experiments/record_volo_messages.py` |

Uncommitted / untracked Phase 1 work:
- `web/` (whole Next.js app, untracked; a diff copy is in `handoff/phase1_interface_wip.patch`).
  `web/.gitignore` already excludes `node_modules`, `.next`, `out`.
- `tests/test_phase1_backends.py` (untracked; imports both openai_plan and volo_contract; passes per
  the VoLo worker) - review and commit it.
- `results/phase1_interface/` (untracked; output of the real G1 backend run) - inspect, commit the
  small evidence files only.
- `handoff/` (this file and the patch).

No processes are running, no GCP VMs exist (`gcloud compute instances list` = 0 items), no cloud
spend was made in this phase. Pre-existing buckets `dream-qwen-20261024-161406-11ebe6`,
`dream-qwen-isaac-20261026-131049-a164c9`, `nerva-adityapersonal-runs` were not created in this phase;
leave them unless the owner says otherwise.

## 4. Objective 1 - interface: state and next steps

Verified by worker (worker-reported unless noted):
- Backend tests pass: `tests/test_phone_api.py`, `tests/test_scheduler.py`, `tests/test_mobile_model.py`;
  ruff clean. New `test_cancellation_during_planning_never_dispatches_a_tool_or_claims_success` (not yet
  shown to fail on the unfixed code - check that).
- Real G1 MuJoCo run driven with curl through the authenticated API: task "inspect cabinet" ->
  `look_around` then `approach` executed; snapshot carried a camera frame, map and one object candidate;
  cancel -> task `cancelled` ("cancelled by user"), run emitted `finish success:false`.
- Web: rewritten in Orbit's visual language (neutral dark palette, Inter, hairline borders, dot grid).
  Files: `app/page.tsx`, `components.tsx`, `types.ts`, `style.css`, `feed.mjs`/`feed.d.mts` (AG-UI event
  reducer), `map.mjs` (`worldToPixel`), `export.mjs`, `next.config.mjs` (dev proxy to the backend, or
  static export when `DREAM_EXPORT=1`), tests `feed.test.mjs`, `map.test.mjs`. `npx tsc --noEmit` clean,
  `next build` (and static export) succeeds, `node --test *.test.mjs` 6 pass.
- **The UI has never been viewed rendered. No screenshots, no `docs/phase1/INTERFACE.md`.**

How to run:
1. Backend: `.venv/Scripts/python.exe -m experiments.phase1_interface --seed 4100 --store <dir>` (~45 s
   to load MuJoCo G1). Auth token file `%LOCALAPPDATA%\DREAM\phone_token`; paste into the UI connect card.
2. UI: `cd web && npm ci && npm run build:export` -> the backend serves `web/out` at
   `http://127.0.0.1:8765/`; or `npm run dev` (proxies to `DREAM_BACKEND_URL`, default 127.0.0.1:8765).

Next steps (Terra):
1. Render at 1440x900 and 390x844; fix layout, map, robot marker and execution-graph rendering.
2. End-to-end on the real backend through the UI: chat submit, camera update, pause, cancel
   ("Stopping..." then "Task cancelled"), notifications, plus disconnected, wrong-token and offline states.
   Voice input via Web Speech API with graceful fallback, if not already present.
3. Screenshots to `docs/phase1/screenshots/`; write `docs/phase1/INTERFACE.md` (setup, token, commands,
   env vars); commit `web/`.
Open issues: camera/map only refresh when a tool runs and the UI polls every 1.2 s (consider SSE/WebSocket
from the existing event stream); event ids restart per backend start (UI resets its cursor on reconnect);
installed `@ag-ui/core` exports types only, so events are not validated at runtime; CopilotKit not used yet
- decide whether it adds value or just weight.

## 5. Objective 2 - ChatGPT vision: state and next steps

Docs check (fetched 2026-10-28, worker-reported): official route exists. Sources:
`https://developers.openai.com/siwc/quickstart` and `.../siwc/token-sharing-open-source/{sign-in,
models-and-inference, preview-limitations, errors-and-recovery, token-reference}`. Eligible Plus/Pro
plans can serve Responses API requests for open-source apps. Authorize
`https://auth.openai.com/api/accounts/authorize`, token `.../api/accounts/oauth/token`; first registration
`client_id=dynamic_agent_client` with `agent_name_hint` and persisted `ext_agent_host_id`, returns an
`oaiapp_*` client id; scopes `openid profile email offline_access resource.invoke chatgpt.tokens.use.direct`,
`resource=https://api.openai.com/v1`; loopback redirect must be `http://127.0.0.1:<port>/auth/callback`;
verify the ID token against JWKS. Inference `POST https://api.openai.com/v1/responses`, streaming,
`store:false`, bearer token; models from `GET /v1/models` (visibility "list"). Limitations: no `system`
role (use developer/instructions); omit `max_output_tokens`, `temperature`, `metadata`; function tools
"must be grouped in namespaces or supplied via additional_tools" (format not shown - look it up before
changing anything). Not documented: refresh request (tokens last 1 h), numeric usage limits, open-source
ToS (points to openai.com/policies).

Measured so far:
- Sign-in succeeded on 27 Oct 13:07 UTC; credential saved outside the repo at
  `%LOCALAPPDATA%\DREAM\openai-chatgpt-plan\oaiapp_DPZvZ6BG3fm33zdPHA2RAvEqd.json` with all six scopes
  (verified by the planner; token values never printed). **That access token has expired.**
- `GET /v1/models` -> 200, 8 models, all text+image: gpt-6.1-sol, gpt-6-astra, gpt-6.1-terra, gpt-6-sol,
  gpt-6-luna, gpt-5.6-sol, gpt-5.6-terra, gpt-5.6-luna. No x-request-id or rate-limit headers.
- All 11 pre-registered decisions on gpt-6.1-sol: `response.failed` after HTTP 200 with
  `subscription_sharing_usage_limit_exceeded` (~4 s each, 0 tokens). The runner now stops on the first
  `subscription_sharing_*` error. Likely cause: the plan quota is shared with the owner's own Codex
  usage, which had just hit its limit (reset reported ~04:51 Sydney, 28 Oct).
- Qwen: not run. No VM existed; the `vlm-compare` workload was added (874eb58) but never launched.
- Decision set: 11 decisions from local MuJoCo G1 head-camera renders of procedural rooms (4 navigation,
  4 object identification, 3 information gathering), accepted answers committed before inference; runs
  through `MobileModelPlanner`, DREAM's real mobile `SCHEMAS` and parser.

Next steps:
1. Ask the owner to confirm plan usage is available (ChatGPT Settings -> Usage), then run the sign-in
   again: `.venv/Scripts/python.exe experiments/openai_plan_login.py --client-id
   oaiapp_DPZvZ6BG3fm33zdPHA2RAvEqd` (the owner completes it in the browser; the token lasts 1 h).
2. Run once: `.venv/Scripts/python.exe experiments/vlm_compare.py gpt --model gpt-6.1-sol`. If rejected
   for tool format, check the docs for the namespace/`additional_tools` format once; do not guess or retry
   in loops.
3. Qwen on GCP (owner's phase brief authorises GPU inference within DREAM's safeguards: one L4, US$6
   ceiling, deletion deadline): `python cloud/launch.py plan --workload vlm-compare --project
   nerva-adityapersonal`, then `cloud/launch.py run --yes --allowance-usd 6`. It needs a clean tracked
   tree (commit everything first). Copy back only `run_qwen-local.json` into `results/phase1_vlm_compare/`;
   confirm the VM and its bucket objects are deleted; append the cost to `isaac_ledger.json` by hand
   (`launch.py` has no ledger).
4. Fill the table and verdict in `docs/phase1/GPT_VISION.md`: valid-call rate, correctness vs pre-written
   answers, latency p50/max, tokens, errors. Verdict caveats already identified: shared opaque plan quota,
   1-h token without a documented refresh (blocks unattended robot use), needs internet (Qwen stays the
   offline fallback), robot-use ToS unverified.

## 6. Objective 3 - VoLoAgent: findings and next steps

Findings (worker-reported, upstream paths under `vlm_orchestrator/`):
1. **Independent execution: no.** VoLo is a proxy (`proxy.py:_handle_session` ~line 310) that needs an eval
   client (RoboLab v0.3.0 on Isaac Sim, not in the repo), a VLA server, an OpenAI-compatible VLM endpoint,
   and for grasp/place a grasp server (`grasp/server.py`, port 8003) using GraspGen (`server.py:82`),
   SAM3/SAM2/GroundingDINO, cuRobo and a Molmo2 sidecar. None of these services or checkpoints are released
   in the repo; README's `utils/vla_stub_server.py` is absent; `protocols/stub.py` is only an in-process
   backend for tool_chain mode.
2. **Embodiment: Franka Panda only.** `grasp/ik.py:78-89` hard-codes Panda FK, Robotiq mount and Franka
   joint limits; `grasp/tool.py:126` assumes the GraspGen Panda gripper;
   `docs/instructions/robolab-robot-support.md:91,118` says no humanoid support. No G1, Dex3 or SONIC
   references anywhere.
3. **GR00T interface:** ZMQ REQ/REP + msgpack, request `{"endpoint":"get_action","data":{"observation":...}}`
   (`gr00t_zmq.py:472-499`); observation images 180x320 (line 47), `state.joint_position` [1,1,7],
   `state.gripper_position`, `state.eef_position/eef_rotation/eef_9d` in robot base frame, three language
   annotations (218-267); action `action.joint_position` [1,N,7] + `action.gripper_position` [1,N,1], chunks
   padded to >=10 (313-345). Internal action is 8-D (7 joint positions rad + binary gripper 0 open/1 closed),
   8 rows per chunk (`grasp/tool.py:78,89`) at 20 Hz (`protocols/stub.py:30`). No whole-body or SONIC path.
4. **DREAM tool mapping:** VoLo `grasp(target, stack)` -> DREAM Toolbox `grasp(object)`;
   `place(destination, held_object_hint, stack)` -> `place(object, target)` (only "table"/"tray" resolve;
   free-form destinations need grounding); noop/advance/replan/abort are planner pointer moves, not tools.
   Failure reasons `perception_no_target`, `ik_unreachable`, `motion_blocked` (`place/tool.py:560-564`);
   grasp success is not verified by the tool (the VLM inspects the next image). Decision schema in
   `strategies/tool_chain.py:46-72, 370-452`.
5. **Incompatibilities (all high severity):** 8-D single-arm action vs G1+Dex3 (~28 dims) under a WBC;
   Franka IK and gripper geometry; binary gripper vs 7-DoF Dex3 hands; requires client RGB-D, camera K,
   extrinsics and EE quaternion; GPU grasp/SAM3/cuRobo services; GR00T DROID checkpoints only (no G1);
   licences of GraspGen, SAM3, Molmo2, cuRobo unverified. VoLo itself is Apache-2.0 (keep NOTICE/attribution).

Reproduced (CPU, separate env `voloenv`): upstream pytest 553 passed / 6 skipped / 1 failed with
`PYTHONUTF8=1` (Windows file lock in `test_gt_metrics.py`; 5 fail without PYTHONUTF8). Passthrough dry run:
mock openpi VLA on :8000 + `vlm-orchestrator --mode passthrough` on :8001 +
`examples/schema_smoke_test.py --grasp --steps 3` -> PASS, actions (8,8) float32. Not run: tool_chain,
grasp/place execution (need GPU services and a VLM). DREAM contract tests pass in `.venv` (upstream
cross-check skipped there) and 22 pass in `voloenv`.

Current recommendation (worker's; you review it): **do not integrate VoLo directly as the manipulation
runtime.** Keep DREAM's Toolbox and TaskAgent; reuse VoLo's decision protocol (subgoal / continue / replan,
failure monitor) and possibly its perception ideas behind typed DREAM tools; do not reuse its Franka-bound
grasp/place executors.

Next steps (Luna, then you):
1. Spot-check the cited upstream lines yourself before accepting the findings.
2. Write `docs/phase1/VOLOAGENT.md`: answers 1-5, what was reproduced, incompatibility table with
   severity and what resolves each, licence check (GraspGen, SAM3, Molmo2, cuRobo), recommendation and
   next-phase steps with costs. Commit.
3. Optional only: a typed wrapper that consumes VoLo's decision JSON and drives DREAM's existing
   grasp/place tools in dry-run (non-actuating). Then stop - no VoLo modifications, training or whole-body
   integration in this phase.

## 7. Finish the phase

1. Commit the untracked Phase 1 pieces after review (`web/`, `tests/test_phase1_backends.py`, small
   evidence from `results/phase1_interface/`, docs). Run focused tests plus `tests/test_cloud.py` and
   `tests/test_g1_cloud.py` (touched by 874eb58).
2. Push `codex/phase1-agentic-interface` once milestones are verified (owner authorised push for this phase).
3. Final report to the owner: what works with evidence (screenshots, test names, run JSON), the GPT vs
   Qwen table and verdict, the VoLo recommendation, blockers, and what remains unimplemented. No
   overstatement.
