import sys,json,math,numpy as np,pathlib
sys.path.insert(0,'.'); sys.path.insert(0,'experiments')
from g1_reach_heights import *
from dream.eval.reach import true_boxes
from dream.robot.g1_rollout import build_rollout_model, settle, _Meter
from dream.robot.g1_supervisor import WholeBodySupervisor, SafetyLimits
cfg=json.loads(pathlib.Path('experiments/configs/g1_reach_heights.json').read_text())
caps=ControllerCapabilities.from_envelope_v2(ROOT/cfg['envelope'])
pc=cfg['planner']
pl=PosturePlanner(caps,PlannerConfig(radii=tuple(pc['radii']),n_angles=pc['n_angles'],max_stances=pc['max_stances']))
sp=[s for s in dev_specs(cfg) if s['id']=='dev_h0.75_L0_s100'][0]
scene=sample_reach_scene(sp['seed'],sp['height'],sp['distance'],sp['lateral'],sp['yaw_jitter'],sp['n_crates'],sp['second_fixture'])
boxes=true_boxes(scene)
res=pl.plan(np.asarray(scene.handle_center),None,(0,0,0),boxes,stances=[(1.089,-0.015,0.0)])
print(len(res.plans),res.reasons())
for plan in res.plans[:2]:
    model=build_rollout_model(boxes)
    env=G1MobileEnv(model,np.random.default_rng(0),head_camera=None); env.reset(*plan.stance)
    be=WBCBackend(env,WBCLocomotion.from_cache(),caps)
    settle(be)
    sup=WholeBodySupervisor(pl.pm,None,None)
    rows=[]
    class Mon:
        def measure(self,obs): return {}
        def __call__(self,obs):
            r=np.abs(obs.tau)/pl.pm.torque_limit
            rows.append((obs.t,r.copy(),obs.prop.q.copy()))
            return None
    rep=be.execute(plan.target,monitor=Mon())
    R=np.array([r[1] for r in rows]); T=np.array([r[0] for r in rows])
    print(plan.arm,'static ratio',round(plan.metrics['torque_ratio'],3),'peak',R.max().round(3),'argmax',sup.joint_names[R.max(0).argmax()])
    for j in np.argsort(-R.max(0))[:3]:
        print('  ',sup.joint_names[j],'limit',pl.pm.torque_limit[j].round(1),'peak',R[:,j].max().round(2),'at t',T[R[:,j].argmax()].round(2),'final',R[-1,j].round(2),'series',R[::10,j].round(2).tolist()[:12])
