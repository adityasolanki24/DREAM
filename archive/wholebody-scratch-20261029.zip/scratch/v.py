import json,sys,math,numpy as np,pathlib
sys.path.insert(0,'.'); sys.path.insert(0,'experiments')
from g1_reach_h3_diagnosis import *
cfg=json.loads(pathlib.Path('experiments/configs/g1_reach_heights.json').read_text())
caps=ControllerCapabilities.from_envelope_v2(cfg['envelope'])
pc=cfg['planner']
pl=PosturePlanner(caps,PlannerConfig(radii=tuple(pc['radii']),n_angles=pc['n_angles'],max_stances=pc['max_stances']))
s=sys.argv[1]
d=json.load(open(f'results/g1_reach_heights_heldout/agent/heldout_s{s}.json'))
sp,tg=d['spec'],d['agent']['target']
scene=sample_reach_scene(sp['seed'],sp['height'],sp['distance'],sp['lateral'],sp['yaw_jitter'],sp['n_crates'],sp['second_fixture'])
boxes=[PerceivedBox(tuple(o['center']),tuple(o['half_extents']),o['yaw'],bool(o['hand_may_touch'])) for o in tg['obstacles']]
tb=true_boxes(scene)
ptar=np.array(tg['position']);cov=np.array(tg['covariance']);ax=face_axis(tg['fixture'],ptar)
def swap(f): return [f if b.hand_may_touch else b for b in boxes]
est=[b for b in boxes if b.hand_may_touch][0]; tru=tb[0]
print('est',est); print('tru',tru)
# est with true top
c=list(est.center);h=list(est.half_extents);c[2]=tru.center[2];h[2]=tru.half_extents[2]
v1=PerceivedBox(tuple(c),tuple(h),est.yaw,True)
# true with est top
c=list(tru.center);h=list(tru.half_extents);c[2]=est.center[2];h[2]=est.half_extents[2]
v2=PerceivedBox(tuple(c),tuple(h),tru.yaw,True)
# est xy-yaw but true top & true depth: use true
for lab,f in ():
    pass
def sd(b,p):
    c,s=math.cos(b.yaw),math.sin(b.yaw); x,y=p[0]-b.center[0],p[1]-b.center[1]
    l=np.array([c*x+s*y,-s*x+c*y]); return l, np.abs(l)-np.array(b.half_extents[:2])
print('handle in est local',sd(est,ptar)); print('handle in true local',sd(tru,np.asarray(scene.handle_center)))
print('truth other boxes',[ (b.center,b.half_extents) for b in tb[1:]])
print('est others',[(b.center,b.half_extents,b.hand_may_touch) for b in boxes if not b.hand_may_touch])
def thin(b,depth_half):
    # shrink est depth (v axis = half[1]) keeping front face
    c,s=math.cos(b.yaw),math.sin(b.yaw); v=np.array([-s,c])
    if b.center[0]*v[0]+b.center[1]*v[1] > 0: v=-v   # v pointing away from robot? ensure v toward robot
    # front face is toward the robot -> direction toward robot is -center; choose sign
    toward=-np.array(b.center[:2]); toward/=np.linalg.norm(toward)
    if v@toward<0: v=-v
    shift=-v*(b.half_extents[1]-depth_half)
    return PerceivedBox((b.center[0]-shift[0],b.center[1]-shift[1],b.center[2]),(b.half_extents[0],depth_half,b.half_extents[2]),b.yaw,True)
for lab,f in (('est_thin',thin(est,0.179)),):
    print(lab,f)
    run(pl,lab,ptar,cov,swap(f),ax,(0,0,0))
c=list(est.center);h=list(est.half_extents);c[2]=tru.center[2];h[2]=tru.half_extents[2]
vt=PerceivedBox(tuple(c),tuple(h),est.yaw,True)
for lab,f in ():
    run(pl,lab,ptar,cov,swap(f),ax,(0,0,0))
print('--- sensitivity of true fixture to face shift toward robot')
n=np.array([math.cos(tru.yaw),math.sin(tru.yaw)])
for mm in ():
    sh=n*mm/1000
    f=PerceivedBox((tru.center[0]+sh[0],tru.center[1]+sh[1],tru.center[2]),tru.half_extents,tru.yaw,True)
    run(pl,f'face+{mm}mm',ptar,cov,swap(f),ax,(0,0,0))
print('--- representation / small perturbations')
H=tru.half_extents
for lab,f in (('rot90',PerceivedBox(tru.center,(H[1],H[0],H[2]),tru.yaw-math.pi/2,True)),
              ('yaw+0.5deg',PerceivedBox(tru.center,H,tru.yaw+0.0087,True)),
              ('yaw+2deg',PerceivedBox(tru.center,H,tru.yaw+0.035,True)),
              ('width-1cm',PerceivedBox(tru.center,(H[0],H[1]-0.01,H[2]),tru.yaw,True)),
              ('zhalf_est',PerceivedBox((tru.center[0],tru.center[1],0.486),(H[0],H[1],0.486),tru.yaw,True))):
    run(pl,lab,ptar,cov,swap(f),ax,(0,0,0))
