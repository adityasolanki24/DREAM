"""Run a script with scratch/overlay/*.py shadowing dream.robot modules (S2 freeze workaround)."""
import pathlib, runpy, sys
HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
import dream.robot as _r  # noqa: E402
_r.__path__.insert(0, str(HERE / "overlay"))
if __name__ == "__main__":
    script = sys.argv[1]
    sys.argv = sys.argv[1:]
    runpy.run_path(str(ROOT / script), run_name="__main__")
