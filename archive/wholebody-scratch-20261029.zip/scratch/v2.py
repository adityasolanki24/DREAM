import json,sys,math,numpy as np,pathlib
sys.path.insert(0,'.'); sys.path.insert(0,'experiments')
from g1_reach_h3_diagnosis import *
cfg=json.loads(pathlib.Path('experiments/configs/g1_reach_heights.json').read_text())
caps=ControllerCapabilities.from_envelope_v2(cfg['envelope'])
pc=cfg['planner']
pl=PosturePlanner(caps,PlannerConfig(radii=tuple(pc['radii']),n_angles=pc['n_angles'],max_stances=pc['max_stances']))
for s in sys.argv[1:]:
    d=json.load(open(f'results/g1_reach_heights_heldout/agent/heldout_s{s}.json'))
    tg=d['agent']['target']
    boxes=[PerceivedBox(tuple(o['center']),tuple(o['half_extents']),o['yaw'],bool(o['hand_may_touch'])) for o in tg['obstacles']]
    ptar=np.array(tg['position']);cov=np.array(tg['covariance']);ax=face_axis(tg['fixture'],ptar)
    def canon(b):
        # local x along the footprint axis most aligned with the robot->box direction (face normal)
        c,sn=math.cos(b.yaw),math.sin(b.yaw)
        u=np.array([c,sn]); v=np.array([-sn,c]); r=np.array(b.center[:2])
        if abs(v@r)>abs(u@r):  # normal along local y -> rotate 90 so it is local x
            return PerceivedBox(b.center,(b.half_extents[1],b.half_extents[0],b.half_extents[2]),b.yaw+math.pi/2,b.hand_may_touch)
        return b
    print(s)
    run(pl,'as_run',ptar,cov,boxes,ax,(0,0,0))
    run(pl,'canon',ptar,cov,[canon(b) for b in boxes],ax,(0,0,0))
