import sys,math,json,pathlib,numpy as np,mujoco
ARMS=("left","right"); PERCEPTION_MARGIN=0.02
sys.path.insert(0,'.'); sys.path.insert(0,'experiments')
from g1_reach_h3_diagnosis import *
exec(open('scratch/sweep.py').read().split("pm=PlanningModel()")[0].split("from dream.robot.g1_posture import *")[0])
cfg=json.loads(pathlib.Path('experiments/configs/g1_reach_heights.json').read_text())
caps=ControllerCapabilities.from_envelope_v2(cfg['envelope'])
pl=PosturePlanner(caps); pm=pl.pm; m=pm.model
d0=json.load(open('results/g1_reach_heights_heldout/agent/heldout_s5008.json')); sp=d0['spec']
scene=sample_reach_scene(sp['seed'],sp['height'],sp['distance'],sp['lateral'],sp['yaw_jitter'],sp['n_crates'],sp['second_fixture'])
tru=true_boxes(scene)[0]; H=tru.half_extents
r90=PerceivedBox(tru.center,(H[1],H[0],H[2]),tru.yaw-math.pi/2,True)
ptar=np.array(d0['agent']['target']['position'])
def brute_any(d,g,b):
    # sample surface points of geom g via mesh verts when mesh, else geom centre only
    if m.geom_type[g]!=mujoco.mjtGeom.mjGEOM_MESH: return None
    mid=m.geom_dataid[g]; v=m.mesh_vert[m.mesh_vertadr[mid]:m.mesh_vertadr[mid]+m.mesh_vertnum[mid]]
    w=v@d.geom_xmat[g].reshape(3,3).T+d.geom_xpos[g]
    c,s=math.cos(b.yaw),math.sin(b.yaw); R=np.array([[c,-s,0],[s,c,0],[0,0,1]])
    loc=(w-np.array(b.center))@R; half=np.array(b.half_extents)+PERCEPTION_MARGIN
    return float(np.linalg.norm(np.maximum(np.abs(loc)-half,0),axis=1).min())
for lab,b in (('true',tru),('rot90',r90)):
    ids=pm.load_obstacles([b]); regular=[]; touch=ids
    limits=pl._limits(regular,touch,0.0)
    n=0
    for stance in [(1.194,-0.253,0.0),(1.094,-0.253,0.0),(1.297,-0.006,-0.785)]:
        for arm in ('left','right'):
            q=pl._ik(pl._q_start(stance),stance,arm,ptar,None,limits)
            if q is None: print(lab,stance,arm,'solver none'); continue
            met,rpy,reasons=pl.evaluate(q,stance,arm,ptar,regular,touch)
            d=pm.data_at(q); ft=np.zeros(6)
            worst=sorted(((mujoco.mj_geomDistance(m,d,g,ids[0],0.1,ft),g) for g in pm.no_foot if g not in {h for s in ARMS for h in pm.hand_geoms[s]}))[:2]
            info=[(round(dist,3),m.body(int(m.geom_bodyid[g])).name,m.geom_type[g],brute_any(d,g,b)) for dist,g in worst]
            print(lab,stance,arm,reasons,round(met['hand_residual'],3),info)
from scipy.spatial import ConvexHull
from scipy.optimize import minimize
def exact(d,g,b):
    mid=m.geom_dataid[g]; v=m.mesh_vert[m.mesh_vertadr[mid]:m.mesh_vertadr[mid]+m.mesh_vertnum[mid]]
    w=v@d.geom_xmat[g].reshape(3,3).T+d.geom_xpos[g]
    c,s=math.cos(b.yaw),math.sin(b.yaw); R=np.array([[c,-s,0],[s,c,0],[0,0,1]])
    loc=(w-np.array(b.center))@R; half=np.array(b.half_extents)+PERCEPTION_MARGIN
    hv=loc[ConvexHull(loc).vertices]
    n=len(hv)
    def f(x):
        w_=x[:n]; y=x[n:]
        return float(np.sum((w_@hv-y)**2))
    x0=np.concatenate([np.ones(n)/n, np.clip(hv.mean(0),-half,half)])
    cons=[{'type':'eq','fun':lambda x: x[:n].sum()-1}]
    bnds=[(0,1)]*n+[(-h,h) for h in half]
    r=minimize(f,x0,constraints=cons,bounds=bnds,method='SLSQP',options={'maxiter':300})
    return math.sqrt(r.fun)
print('--- exact checks')
for lab,b,stance,arm in (('rot90',r90,(1.094,-0.253,0.0),'right'),('true',tru,(1.297,-0.006,-0.785),'left')):
    ids=pm.load_obstacles([b]); regular=[]; touch=ids
    limits=pl._limits(regular,touch,0.0)
    q=pl._ik(pl._q_start(stance),stance,arm,ptar,None,limits); d=pm.data_at(q); ft=np.zeros(6)
    for nm in (f'{arm}_wrist_pitch_link',f'{arm}_wrist_roll_link',f'{arm}_elbow_link'):
        for g in np.flatnonzero(m.geom_bodyid==m.body(nm).id):
            if m.geom_type[g]!=mujoco.mjtGeom.mjGEOM_MESH or not m.geom_contype[g]: continue
            print(lab,nm,'mj',round(mujoco.mj_geomDistance(m,d,g,ids[0],0.5,ft),3),'exact',round(exact(d,g,b),3))
