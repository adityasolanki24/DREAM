import sys,math,numpy as np,mujoco,json,pathlib
sys.path.insert(0,'.'); sys.path.insert(0,'experiments')
from g1_reach_h3_diagnosis import *
cfg=json.loads(pathlib.Path('experiments/configs/g1_reach_heights.json').read_text())
caps=ControllerCapabilities.from_envelope_v2(cfg['envelope'])
pl=PosturePlanner(caps)
d=json.load(open('results/g1_reach_heights_heldout/agent/heldout_s5008.json'))
sp=d['spec']
scene=sample_reach_scene(sp['seed'],sp['height'],sp['distance'],sp['lateral'],sp['yaw_jitter'],sp['n_crates'],sp['second_fixture'])
tru=true_boxes(scene)[0]; H=tru.half_extents
r90=PerceivedBox(tru.center,(H[1],H[0],H[2]),tru.yaw-math.pi/2,True)
pm=pl.pm; m=pm.model
stance=(1.194,-0.253,0.0)
q=pl._q_start(stance)
# arm forward config: raise left shoulder pitch a bit
q[pm.qadr[15]]=-1.2; q[pm.qadr[18]]=0.8
dd=pm.data_at(q)
ft=np.zeros(6)
for lab,b in (('true',tru),('rot90',r90)):
    ids=pm.load_obstacles([b]); g=ids[0]; mujoco.mj_forward(m,dd)
    mujoco.mj_forward(m,dd)
    out=[]
    for gg in pm.no_foot:
        out.append(mujoco.mj_geomDistance(m,dd,gg,g,0.3,ft))
    print(lab,np.round(sorted(out)[:6],4), m.geom_pos[g], m.geom_size[g], m.geom_quat[g])
print('--- feasible plan under true; distances under both reps')
ptar=np.array(d['agent']['target']['position'])
res=pl.plan(ptar,None,(0,0,0),[tru],approach_axis=None)
print(len(res.plans))
p=res.plans[0]; print(p.stance,p.arm)
dd=pm.data_at(p.target.q)
for lab,b in (('true',tru),('rot90',r90)):
    ids=pm.load_obstacles([b]); g=ids[0]; mujoco.mj_forward(m,dd)
    out=sorted((mujoco.mj_geomDistance(m,dd,gg,g,0.3,ft),m.body(int(m.geom_bodyid[gg])).name) for gg in pm.no_foot)[:4]
    print(lab,[(round(a,4),n) for a,n in out])
res2=pl.plan(ptar,None,(0,0,0),[r90],approach_axis=None); print('rot90 plans',len(res2.plans),res2.reasons())
res3=pl.plan(ptar,None,(0,0,0),[tru],approach_axis=None); print('true plans',len(res3.plans),res3.reasons())
print('--- brute-force check')
def vdist(gg,b):
    mid=m.geom_dataid[gg]; v=m.mesh_vert[m.mesh_vertadr[mid]:m.mesh_vertadr[mid]+m.mesh_vertnum[mid]]
    w=v@dd.geom_xmat[gg].reshape(3,3).T+dd.geom_xpos[gg]
    c,s=math.cos(b.yaw),math.sin(b.yaw)
    R=np.array([[c,-s,0],[s,c,0],[0,0,1]])
    loc=(w-np.array(b.center))@R
    half=np.array(b.half_extents)+0.02
    return float(np.linalg.norm(np.maximum(np.abs(loc)-half,0),axis=1).min())
for gg in pm.hand_geoms['right'][:6]:
    if m.geom_type[gg]!=mujoco.mjtGeom.mjGEOM_MESH: continue
    row=[]
    for b in (tru,r90):
        ids=pm.load_obstacles([b]); mujoco.mj_forward(m,dd); row.append(round(mujoco.mj_geomDistance(m,dd,gg,ids[0],0.3,ft),4))
    print(m.body(int(m.geom_bodyid[gg])).name,row,'brute',round(vdist(gg,tru),4),round(vdist(gg,r90),4))
