import sys; sys.path.insert(0,'scratch')
from pt import patch
patch('dream/robot/g1_supervisor.py',[
('''        self.pm = planning_model
        self.limits = limits or SafetyLimits()
''','''        self.pm = planning_model
        m = planning_model.model
        # body joint names in actuator order, to say WHICH joint triggered a stop (logging only)
        self.joint_names = [m.joint(int(m.actuator(i).trnid[0])).name for i in range(29)]
        self.limits = limits or SafetyLimits()
'''),
('''            "torque_ratio": ratio,
            "tilt": float(tilt(p.quat)),''','''            "torque_ratio": ratio,
            "torque_joint": int(np.argmax(np.abs(obs.tau) / self.pm.torque_limit)),
            "tilt": float(tilt(p.quat)),'''),
('''            return self._stop(obs, "joint position limit", {"joint": float(bad[0])})''',
 '''            return self._stop(obs, "joint position limit", self._joint(bad[0], q=q))'''),
('''            return self._stop(obs, "joint velocity limit", {"joint": float(fast[0])})''',
 '''            return self._stop(obs, "joint velocity limit", self._joint(fast[0], dq=p.dq))'''),
('''            return self._stop(obs, "torque limit", {"ratio": float(ratio.max())})''',
 '''            return self._stop(
                obs, "torque limit", {"ratio": float(ratio.max()), **self._joint(ratio.argmax())}
            )'''),
('''    def _stop(self, obs: Observation, reason: str, detail: dict[str, float]) -> StopEvent:''',
'''    def _joint(self, i, q=None, dq=None) -> dict[str, object]:
        """Which joint triggered a stop (index and name), with its value when given."""
        i = int(i)
        out: dict[str, object] = {"joint": float(i), "joint_name": self.joint_names[i]}
        if q is not None:
            out["q"], out["range"] = float(q[i]), self.pm.joint_range[i].tolist()
        if dq is not None:
            out["dq"] = float(dq[i])
        return out

    def _stop(self, obs: Observation, reason: str, detail: dict[str, float]) -> StopEvent:'''),
])
patch('dream/robot/g1_rollout.py',[
('''        self.peak = dict.fromkeys(''','''        self.peak_joint = 0
        self.peak = dict.fromkeys('''),
('''        self.peak["torque_ratio"] = max(
            self.peak["torque_ratio"], float(np.max(np.abs(obs.tau) / self.pm.torque_limit))
        )''','''        ratio = np.abs(obs.tau) / self.pm.torque_limit
        if float(ratio.max()) > self.peak["torque_ratio"]:
            self.peak["torque_ratio"], self.peak_joint = float(ratio.max()), int(ratio.argmax())'''),
('''        "peak_torque_ratio": meter.peak["torque_ratio"],''','''        "peak_torque_ratio": meter.peak["torque_ratio"],
        "peak_torque_joint": float(meter.peak_joint),'''),
])
