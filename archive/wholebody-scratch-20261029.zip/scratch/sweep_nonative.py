import sys,math,numpy as np,mujoco
sys.path.insert(0,'.')
from dream.robot.g1_posture import *
pm=PlanningModel(); m=pm.model
MODE='nonative'
if MODE=='iter': m.opt.ccd_iterations=1000; m.opt.ccd_tolerance=1e-10
if MODE=='nonative': m.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_NATIVECCD)
print(m.opt.ccd_iterations, m.opt.ccd_tolerance)
q=pm.q_nominal.copy(); q[0]=1.094; q[1]=-0.253
ft=np.zeros(6)
geoms=[g for g in pm.hand_geoms['right']+pm.hand_geoms['left'] if m.geom_type[g]==mujoco.mjtGeom.mjGEOM_MESH]
def brute(d,g,b):
    mid=m.geom_dataid[g]; v=m.mesh_vert[m.mesh_vertadr[mid]:m.mesh_vertadr[mid]+m.mesh_vertnum[mid]]
    w=v@d.geom_xmat[g].reshape(3,3).T+d.geom_xpos[g]
    c,s=math.cos(b.yaw),math.sin(b.yaw); R=np.array([[c,-s,0],[s,c,0],[0,0,1]])
    loc=(w-np.array(b.center))@R
    half=np.array(b.half_extents)+PERCEPTION_MARGIN
    return float(np.linalg.norm(np.maximum(np.abs(loc)-half,0),axis=1).min())
rng=np.random.default_rng(0)
bad={'over':0,'under':0,'n':0}; byratio=[]
for t in range(60):
    hx,hy=rng.uniform(0.15,0.45,2); hz=rng.uniform(0.3,0.7)
    yaw=rng.uniform(-3,3)
    cx=1.45+rng.uniform(-.1,.1)
    b=PerceivedBox((cx,-0.25+rng.uniform(-.3,.3),hz),(hx,hy,hz),yaw)
    ids=pm.load_obstacles([b]); d=pm.data_at(q)
    for g in geoms:
        br=brute(d,g,b)
        if br>0.6: continue
        mj=mujoco.mj_geomDistance(m,d,g,ids[0],1.0,ft)
        bad['n']+=1
        e=mj-br
        if e>0.02: bad['over']+=1; byratio.append(('over',hx>hy))
        if mj<0 and br>0.03: bad['under']+=1; byratio.append(('false_pen',hx>hy))
print(bad)
from collections import Counter; print(Counter(byratio))
