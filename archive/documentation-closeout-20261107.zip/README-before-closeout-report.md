# DREAM

Research toward general-purpose embodied intelligence: receive an unfamiliar physical goal,
observe, investigate, compose available skills, verify the outcome, and recognise limits.
**General-purpose task completion is the objective, not an established capability.**
`AGENTS.md` is the authoritative engineering and behavioural contract; `CLAUDE.md` aliases it.

## Current status — 31 October 2026

**This checkout: `codex/g1-runtime-builder-20261028`.** Combined interface and runtime development: model picker, full-frame camera, language-goal routing, cached-image build, genuine Isaac/Qwen run, idle-balance correction and exact local inspection audit. Instance-bound inspection semantics, bounded model-led recovery and local physical-loop checks are implemented. A fresh cloud evaluation is pending.

| Component | Evidence-backed status | Limits / next work |
|---|---|---|
| Active physical discovery | Force-limited probing, Bayesian mechanism belief and information-gain experiment selection; held-out results preserved under `results/` | Abstract gantry and narrowed Panda tasks; no general physical reasoning claim |
| Panda manipulation and discovery | Contact-based skills and independently verified structured tasks; historical camera pick-and-place 39/40; compartment drawers/lids 27/30 each | Camera mechanism discovery remains unreliable; validated compartment work uses oracle-assisted tracking and disclosed scene simplifications |
| G1 mobility in MuJoCo | NVIDIA Decoupled WBC contract audited; historical locomotion and search gates passed | Velocity-commanded locomotion; arms held; this is a pretrained motor controller |
| Classical room search | Held-out nominal 20/20, shifted 8/10, no-cabinet 6/6 correct refusals | Oracle-assisted odometry; colour/depth perception; furniture contact occurred in 18/66 historical episodes |
| Navigation, memory and interruption | RPP navigation, SQLite home/experience memory, scene graph and interruptible phone API implemented on the later kitchen/interface branches | Use the frozen results and their caveats; none establish unrestricted autonomy or validated SLAM |
| App and model selection | Desktop/mobile mission control, camera, chat, provider/model selection, task events and pause/cancel; genuine app-to-cloud execution recorded | Full camera frame is contained, not cropped. Voice UI exists; reliable end-to-end spoken task completion has not been established |
| Natural-language goals | Configured VLM can interpret nonempty language into typed supported goals | Mobile goals bind observed candidate IDs, observed reachable frontiers/viewpoints or remembered places. Unsupported manipulation requests receive structured refusals; arbitrary physical goals are not supported |
| Camera delivery | Cached binary JPEG with unique frame IDs, change-based fetch, independent media polling and reconnect/slow-encoder regressions | Separate 640×360 NVENC/MediaMTX/WHEP implementation is experimental; only software-codec plumbing tested locally. ICE/TCP over private IAP is a fallback; 10 FPS and sub-800 ms glass-to-glass are not established |
| Cached cloud runtime | Immutable image `4812387390768042548`; locked CUDA 12.8, L4, MuJoCo 3.16 and actual inference/physics preflight verified | Image-build receipt records recovery from a post-creation JSON parsing error; its manipulation attempt failed release verification |
| Genuine Isaac/Qwen run | Isaac Sim 6.2 / PhysX / Unitree G1, Qwen3-VL-4B-Instruct; pinned checkpoint revision `ebb281ec70b05090aa6165b016eac8ec08e71b17` | Development demonstration only; cabinet task completion failed |
| GPT/VoLoAgent work | Official ChatGPT sign-in backend and a small frozen-decision interface pilot; VoLoAgent non-actuating contract work | No completed matched physical GPT/Qwen comparison; no validated VoLoAgent actuation |
| Whole-body W6 | Development agent/baseline/reference runs and review preserved on `claude/wholebody-autonomy` | Failed gates and rollback/reference/attribution questions remain; no frozen held-out result or readiness for integration |

Historical measurements above are scoped to their original code, configurations and seeds.
A documentation refresh does not rerun or revalidate them. Detailed earlier reports,
commands, licence notes and simplification audits remain in the documentation archive and Git.
Original results and hard failure cases have not been removed or rescored.

## Latest Isaac failure and exact local audit

The first live task passed ten seconds of controlled standing, then detected a 62-degree
pelvis tilt at 10.02 s. Kit updates in the idle server advanced physics without WBC ticks.
The correction removes uncontrolled idle updates, captures a frame before API readiness,
and rejects further tasks after a physical safety stop. Three focused CPU regressions passed.

A real retry at `65ce8b3` completed `look_around` and `inspect(candidate=2)` without a fall,
reaching 26.52 s of simulation time including standing. It **did not complete the goal**:
inspection reported tool success while `at_inspection_pose=false`, the verifier reported
"not on the handle's side of the object", and Qwen explicitly called `finish(success=false)`.
Raw decisions and both failed attempts remain in `results/isaac_live_idle_failure` on the
runtime branch and in the external cloud results.

The exact saved refusal has now been replayed locally. An exhaustive audit of the saved
estimated map found:

- Candidate 2: 41 reachable cells satisfy the existing inspection-pose predicate, but the
  old sampler omitted them. Its only offered side-5 viewpoint was 2.12 m from the handle
  and was not a valid inspection pose. Its detected handle was assigned side 1.
- Candidate 9: 364 cells satisfy the original distance/side/heading predicate. The added
  occupancy-ray audit rejects its proposed side-4/5 viewpoints because the handle sightline
  is occluded. A walkable path alone does not establish a valid inspection; these poses
  are no longer advertised. Side 0 also fails the original predicate.
- These are **estimated-map reachability results**, not proof of physical reachability or
  correct handle association in Isaac. Original raw RGB-D was not preserved for this run.

Audit source, exact input and original reproduction are under
`experiments/audit_mobile_inspection.py` and `results/mobile_inspection_semantics` on the
runtime branch. Regression tests now cover wrong-side partial inspection, unreachable or
occluded handle sides, misleading success, alternative-viewpoint selection, instance binding,
unsupported requests and bounded search exhaustion. Inspection records separately report
`handle_observed`, `at_inspection_pose` and `inspection_complete`. A partial observation returns
an incomplete action result; only measured completion can satisfy an instance-bound goal.
Qwen retains tool selection, with bounded repair calls for inadmissible actions or premature
finishes. There is no scripted replacement for model decisions in the cloud runtime.

Two CPU development episodes ran the complete RGB-D perception/navigation/verification loop
with the unchanged MuJoCo G1 and WBC, using an explicitly deterministic **test baseline**:
seeds 0 and 2 passed independent ground-truth verification, with zero recorded contacts,
zero safety stops and zero false success claims. They used 37.52/39.82 simulated seconds and
5.31/5.12 m of travel. These are development cases from the familiar generator, not held-out
or Qwen results. Conditions, paths, tool outcomes and negative media attempts are preserved
in `results/mobile_recovery_20261031`. Historical search scores above remain historical;
the changed viewpoint selection has not been re-evaluated on the old held-out distribution.

### Closeout corrections after the 1 Nov genuine-Qwen sessions

Four genuine Qwen sessions (31 Oct and three on 1 Nov; development, interactive, not
predeclared, simulation, oracle-assisted odometry) are preserved in
`results/isaac_qwen_live_20261101` with checksums and `summary.json`. They exposed two
defects, now corrected and regression-tested (`tests/test_closeout_defects.py`,
`tests/test_isaac_live_replay.py`): a "walk to the refrigerator" request bound to a frontier
the robot already stood on was reported as success, and a viewpoint 1.37 m from a handle
against a 1.40 m limit was chosen although arrival errors of 0.10-0.12 m were measured.
Reaching a frontier is now an explicit incomplete outcome
(`exploration_point_reached_target_unverified`, success false), the final reason text is
generated from the typed verdict (the model's text is kept as `model_reason`), and viewpoints
leave a 0.15 m arrival margin (the inspection predicate is unchanged). Live tasks are now scored
by task type (`dream/eval/task_scoring.py`; the new scoring has not yet run in Isaac). The cloud
cost guard now reads every desktop app's ledger, because the Claude and Codex apps virtualise
`%LOCALAPPDATA%`. The deterministic CPU loop was re-run on the corrected code
(`results/mobile_recovery_closeout_20261106`): seeds 0 and 2 both passed independent
verification with zero contacts, zero safety stops and zero false claims; seed 0 is unchanged
(37.52 s, 5.31 m) and seed 2 now finishes in 22.32 s over 2.39 m (was 39.82 s, 5.12 m) because
the first viewpoint it reaches now satisfies the inspection predicate. These remain development
cases, not held-out or Qwen results. 

### Qwen closeout evaluation and remote camera measurement (7 Nov 2026)

`results/isaac_qwen_closeout_20261107`: genuine Qwen3-VL-4B on the Isaac G1, **development kitchen
(l_shape), predeclared (frozen config), not held-out**, starts 7/8/9, tasks T1-T5, odometry
oracle-assisted, physics frozen during inference. Gates: false claims 0 FAIL (3 claims on T3/T4),
falls 0 PASS, T4 no claim FAIL (2/3), T3 no claim FAIL (1/3), T1 independent success 3/3 PASS,
T2 3/3 PASS (two of three took zero steps: the chosen candidate was the one T1 had just inspected),
T5 unverifiable (refused as unsupported in all three). "Walk to the refrigerator" was bound to the
remembered place "entrance" and verified there, which is not a refrigerator.
`results/camera_delivery_cloud_20261107`: IAP measurements of real Isaac frames. The 31 Oct WHEP
failure was MediaMTX's 10 s read timeout closing the publisher while the synchronous simulation
published nothing (fixed with readTimeout 3600 s, verified); WHEP latency and Tailnet were not
measured. See each `summary.json` for numbers and labels.

| Change | Classification | Evidence and remaining limit |
|---|---|---|
| Instance-bound goal verification and incomplete-inspection results | General algorithmic correction | Saved failures and regression tests; no physics or scene simplification |
| Reachable inspection-cell selection with handle-side, heading and sightline checks | General algorithmic correction | Saved candidate 2/9 audit and two independent development physics cases; estimated-map geometry remains fallible |
| Frontier reached is exploration, not task completion; no reached frontier offered | General algorithmic correction | 1 Nov session replay and unit tests; independent cases are the two development episodes above, not held-out |
| Viewpoint arrival margin 0.15 m | General algorithmic correction | Saved 1 Nov map replay; seed 2 re-run; margin chosen from two measured arrival errors, not tuned on held-out data |
| Cost guard reads all desktop apps' ledgers | General algorithmic correction | Offline regression tests; the combined ledger and earlier-run estimates now exceed the previous per-app view |
| Latest-only JPEG and separate NVENC/WHEP publisher | Delivery engineering | Auth/cache/drop/reconnect tests; 40/40 frames encoded and recorded with local software codec after two preserved failed plumbing attempts; cloud NVENC and real browser playback pending |

The final fast suite passed 503 tests (one skipped), and the 31 JavaScript tests and production
build passed. Lint/format and isolation passed. The complete slow suite remains pending.
On eight saved real camera observations, offline median PNG/base64 encoding took 11.10 ms
and 178,256 bytes; JPEG quality 80 took 0.56 ms and 7,780 bytes. These are encoding/payload
measurements, **not** live FPS or end-to-end latency (`encoding_benchmark.json`).

The next gate is one genuine Qwen evaluation in the unchanged existing Isaac kitchen, with
raw sensor snapshots, model inputs/outputs, paths, independent instance-specific verification
and a recorded camera stream. The idle-balance correction, original dynamics and safety limits
remain. No fresh cloud task success or live video latency is claimed yet.

### Remaining closeout evaluations (7 Nov 2026)

**Compartment, oracle reference** (`results/compartment_oracle_reference_closeout`): the same
seeds 5200-5209 per kind as the frozen vision run, perception oracle, same code path.
Oracle 20/20 openable and 10/10 fixed declined, no false claims; the vision run
(`results/compartment_vision_closeout`) remains the camera-discovery result at 11/20 and
fails its gate. On the same seeds, the 9 openable seeds the vision arm failed all succeeded
with oracle perception (per-seed table in `vision_vs_oracle.json`). Observational: the arms
differ in perception only, which is consistent with perception being the limiting component
but is not a controlled ablation of why each seed failed.

**Room exploration revalidation** (`results/g1_explore_room_closeout`, frozen config
`g1_explore_room_closeout.json`, 60 rows, cloud, code a3b4304): gates **FAIL**. Nominal gain
success 15/20 = 0.75 (gate 0.9; 15/18 = 0.83 if the two seeds with no valid room, 1313 and
1319, are excluded, still below), shifted gain 4/10 = 0.40 (gate 0.7), no_cabinet refusal 10/10
(pass, 10/10 strict, none phantom-driven), false claims 0 and falls 0 (pass). Every failure is a
refusal or budget stop, none a false claim. Frontier comparison (shifted and no_cabinet, 20
pairs): 7 divergent decisions, fewer than the declared 10, so insufficient divergence, no claim
(mean sim_s difference +1.5 s, interval -1.2 to +5.1). Hand-on-furniture contact in 23 of 60
episodes, hand-on-handle in 5, no foot contact; phantom handles in 11 episodes (15 total). Two
failed cloud attempts are in `failed_attempts/`; the earlier local hang did not recur.

**Room regression diagnostic** (`results/g1_explore_room_regression_closeout`, frozen config
`g1_explore_room_regression_closeout.json`; a diagnostic, not held-out and not a replacement for
the result above; gain arm only, one cloud session): with the current code on the historical
seeds (A1) nominal is 19/20 against 20/20 in `results/g1_explore_room` and shifted 6/10 against
8/10 (seeds 1013, 2000, 2004 changed, all refusals or budget stops, no false claims or falls),
so by the declared rule there is a code regression since 44ab7c4, not located to a commit. With
only the 0.15 m arrival margin removed on the frozen fresh seeds (A2, sibling branch never
merged) all 40 outcomes are unchanged (15/20, 4/10, 10/10), including the five 'no reachable
viewpoint' failures, so the margin is not what causes them; the margin was not tested on the
three regression seeds. Seed difficulty also contributes: current code scores 19/20 and 6/10 on
the historical seeds and 15/20 and 4/10 on the fresh ones, two of whose nominal failures are
rooms with no valid start. No fix has been applied.

**Room regression bisect** (`results/g1_explore_room_bisect_closeout`, frozen config
`g1_explore_room_bisect_closeout.json`; a diagnostic, not held-out; seeds 1013, 2000, 2004, gain
arm, 14 commits from 44ab7c4 to a3b4304, each run from a byte copy of its own `dream/`, one cloud
session plus a supporting Windows run): the historical result reproduces on the cloud VM only
with software rendering (`MUJOCO_GL=osmesa`: all three seeds bit-identical to history); with the
guest's default `egl` seeds 2000 and 2004 already fail at the unchanged 44ab7c4, so those two
A1 'regressions' are the renderer (and, under EGL, 1 mm start shifts flip them) rather than a
commit. Seed 1013 is a real regression that flips at b8208bb in all three environments: its
`side_point` rewrite picks the cheapest reachable cell in the 0.6-1.4 m band, the robot lands
0.4-0.55 m from the handle (below the band) on every retry, and the stricter inspection rule
(which the old success had bypassed through a stale confirmation flag) then rejects it until the
240 s budget; reverting only that rewrite restores the success. The arrival margin changes
nothing. Every cloud room result since the closeout used EGL, the historical one did not; how much
of the frozen 15/20 and 4/10 that explains was not tested. No fix has been applied.

**Qwen on the frozen provider frames** (`results/p6_qwen_frozen11_closeout`, frozen config
`p6_qwen_frozen11_closeout.json`): the same 11 decisions, frames, prompt and tool schemas
(hash-equal to the ChatGPT run's offline reconstruction) and scorer. Qwen3-VL-4B-Instruct at
revision ebb281ec, greedy, one pass: valid 11/11, correct 5/11. The ChatGPT run (gpt-6-luna,
effort none) was valid 11/11, correct 6/11. They agree on the correctness of 10 of 11 frames; the
single paired disagreement is `obj_6` (ChatGPT inspected candidate 0, Qwen looked around). With
n = 11 this is a descriptive count only: no superiority claim either way. Differences that cannot
be removed (backend rendering of the same messages, decoding settings, the ChatGPT run's own
runner bytes) are listed in the config.

**MolmoAct2 failure mode** (`results/molmo_failure_mode_closeout/summary.json`, saved
evidence only, no new inference): the gripper channel stayed within [-0.006, 0.011] and DREAM
maps it to fully open, the upstream DROID convention; the end effector stayed at least 0.43 m
from the object because the pilot executed 6 single rows (0.4 s of policy time); the DREAM home
pose is outside the DROID state range for two wrist joints. No contract defect found. Learned
integration: partial. Task execution: no. The pre-registered multi-chunk test then ran
(`results/molmo_multichunk_closeout`, frozen config `molmo_multichunk_closeout.json`, one cloud job,
seed 223, 10 fresh inferences x 15 consecutive rows = 10 s of policy time, 150 of 150 targets
reached with tracking within 0.002 rad and no safety stop): the end effector got no nearer than
0.298 m (start 0.536 m, end 0.347 m) and the raw gripper channel never exceeded 0.011, so by the
registered rule H4 (policy or embodiment gap) stands and the under-length evaluation (H1) is
rejected as the cause. Task execution: no (0/1). The start-pose and camera contract factors (H3)
were not varied and remain open; this is one development seed and one rollout. See
`results/molmo_failure_mode_closeout/multichunk_conclusion.json`.

## Branches and integration

| Branch | Role |
|---|---|
| `main` | Stable integration line; only changes that pass the applicable checks are integrated |
| `codex/g1-runtime-builder-20261028` | Combined active interface, model comparison, runtime image, Isaac integration and unfinished inspection audit |
| `claude/wholebody-autonomy` | Separate active whole-body research, with unresolved W6 gates |

The interface branch was consolidated into the runtime branch. Its original tip remains
archived. The main working folder now uses the combined runtime branch; the earlier runtime
worktree is retained as a detached snapshot. Both documentation archives and all staged/
untracked checkpoints are retained.

Retired branch heads are retained by annotated `archive/2026-10-29/...` tags. Do not merge
unfinished research solely to remove a branch. Runtime/kitchen integration is currently
blocked by the existing `dream/skills/g1_reach.py` import of `mujoco`, which violates the
simulator-isolation test. The invariant must not be weakened. W6 is separately blocked by
its development review. Work-in-progress commits preserve work; they do not certify it.

## Setup and focused checks

Core CPU environment (Python 3.10+; use the project environment, not an unrelated system Python):

```powershell
python -m venv .venv
.venv/Scripts/python.exe -m pip install -e ".[dev,demo,locomotion]"
.venv/Scripts/python.exe -m pytest tests/test_isolation.py -q
```

MuJoCo is pinned to 3.16.0. Keep Isaac and VLM dependencies in their separately locked
runtimes. Do not resolve them into the core CPU environment. Inspect `pyproject.toml` for
optional scene-graph, SLAM, model and dataset extras. Preserve upstream licences/provenance.

On the interface/runtime branches:

```powershell
.venv/Scripts/python.exe -m experiments.phase1_interface --help
cd web
npm ci
npm run dev
```

Use the backend's protected local token; do not commit tokens, credentials or checkpoints.
The structured provider is explicitly labelled as having no language model. Select a configured
VLM for language interpretation. Model selection never grants raw joint control.

Runtime audit reproduction (CPU; not a new model call or physics evaluation):

```powershell
.venv/Scripts/python.exe -m experiments.audit_mobile_inspection --saved results/mobile_inspection_semantics/saved_failure.json --out <new-audit-output.json>
```

The historical fast suite exceeds the intended 60-second target. Run focused tests during
changes; complete the required integration/physical checks at a milestone. Never use a mock
inference result as evidence of a genuine VLM demonstration.

## Cloud lifecycle and results

DREAM cloud jobs use the scoped `cloud/` tooling in project `nerva-adityapersonal` with
estimated job/cumulative cost guards, immutable source snapshots and machine-enforced VM
expiry. Actual billed cost has not been established; estimates must not be labelled bills.
The latest Isaac session's scoped compute/network/identity cleanup returned no errors.
The initial stop rejected a missing root result manifest; recovery independently verified all
66 saved output objects against GCS MD5/size metadata and retained local SHA-256 hashes before
deleting the bucket (absence confirmed by a 404). The reconciled runtime-based estimate is
US$5.30, against the original US$7.65 maximum-lifetime estimate; actual billing is unavailable.
`results/cloud_isaac_20261029_cleanup` records the recovery and its limits. The separate older DREAM NAT/router/network/subnet and service account have also now been
removed. The final inventory shows zero VMs, disks, reserved addresses, routers, snapshots
or forwarding rules; only the default network remains. Historical bucket outputs were
retrieved and independently hash-verified before deletion. The validated runtime image is
retained at the owner's request (24.5 GiB; approximately US$1.23/month at the published image
storage rate). Cloud Storage soft-deleted bytes may remain billable until their seven-day
retention expires; deleting a bucket does not imply immediate zero storage billing. NERVA
resources are outside this cleanup. No fresh paid evaluation was launched.

Weights, caches, credentials and large raw recordings remain outside Git/OneDrive, normally
under `%LOCALAPPDATA%/DREAM`. Compact evidence, source and result metadata are committed.
The supplied small portfolio recording is maintained in the separate Portfolio repository.

## Documentation and preserved history

This README is the maintained status/setup entry point. First-party handoff prompts,
transcripts and duplicate status documents were consolidated and preserved verbatim in
`archive/documentation-runtime-20261029.zip`, including this branch's previous full README.
Licence/provenance files, `AGENTS.md`, its `CLAUDE.md` alias, and original experiment records
are retained. The whole-body scratch copy is archived separately rather than left as another
working source tree. Archives are historical evidence, not current instructions.

A pre-consolidation backup contains Git bundles for every branch, staged/unstaged binary
patches, untracked-file ZIPs and a SHA-256 inventory. Its location is recorded outside Git at
`%LOCALAPPDATA%/DREAM/archives/latest-consolidation.txt`. Credential-pattern scanning of the
pending material found no matches; private runtime credentials remain outside these commits.

## Repository consolidation checks

The foundation source at `287cd67` passed 328 fast tests, including isolation, before
fast-forward integration into `main`. The combined interface/runtime tree passed focused
model-choice, backend, tool-runtime, comparison-summary and Isaac idle regressions. Its
unchanged interface files passed 30 web unit checks and the production build (with one
existing CSS compatibility warning). The Portfolio production build and TypeScript checks
passed after the video and recovered role media were integrated.

There are no open pull requests in DREAM or Portfolio as of this cleanup. Seven retired
DREAM branch heads and six Portfolio branch heads are recoverable through annotated archive
tags; only the three DREAM branches listed above and Portfolio `main` remain. Unfinished
runtime and W6 work were not represented as validated or merged into stable `main`.
