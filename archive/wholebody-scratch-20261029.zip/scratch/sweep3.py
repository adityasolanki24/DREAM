import sys,math,numpy as np,mujoco
sys.path.insert(0,'.')
exec(open('scratch/sweep.py').read().split("rng=np.random")[0])
b=PerceivedBox((1.45,-0.25,0.5),(0.3,0.18,0.5),1.74)
ids=pm.load_obstacles([b]); d=pm.data_at(q)
g=[x for x in geoms if m.body(int(m.geom_bodyid[x])).name=='right_hand_index_1_link'][0]
print('mesh,box',mujoco.mj_geomDistance(m,d,g,ids[0],1.0,ft),'box,mesh',mujoco.mj_geomDistance(m,d,ids[0],g,1.0,ft),'brute',brute(d,g,b))
print('geom type',m.geom_type[g],m.geom_dataid[g],'contype',m.geom_contype[g],m.geom_conaffinity[g], 'margin',m.geom_margin[g],m.geom_gap[g])
print('hand pos',d.geom_xpos[g], 'box', d.geom_xpos[ids[0]])
# exact via SLSQP
from scipy.optimize import minimize
mid=m.geom_dataid[g]; v=m.mesh_vert[m.mesh_vertadr[mid]:m.mesh_vertadr[mid]+m.mesh_vertnum[mid]]
w=v@d.geom_xmat[g].reshape(3,3).T+d.geom_xpos[g]
c,s=math.cos(b.yaw),math.sin(b.yaw); R=np.array([[c,-s,0],[s,c,0],[0,0,1]])
loc=(w-np.array(b.center))@R; half=np.array(b.half_extents)+PERCEPTION_MARGIN
# distance of hull to box = min over hull points; use qp over convex weights (nnls on 3 dims is awkward) -> sample random convex combos
print('n verts',len(v),'min vertex dist',np.linalg.norm(np.maximum(np.abs(loc)-half,0),axis=1).min())
print('box local of hand verts min/max',loc.min(0),loc.max(0),'half',half)
