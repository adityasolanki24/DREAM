import sys
def patch(path, pairs):
    s = open(path, newline='').read()
    crlf = '\r\n' in s
    s = s.replace('\r\n', '\n')
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:80], s.count(a))
        s = s.replace(a, b)
    open(path, 'w', newline='').write(s.replace('\n', '\r\n') if crlf else s)
