import sys,math,numpy as np,mujoco
sys.path.insert(0,'.')
exec(open('scratch/sweep.py').read().split("rng=np.random")[0])
c=(1.72,-0.34,0.676); H=(0.199,0.436,0.676); yaw=2.68
reps={'A':PerceivedBox(c,H,yaw),'B':PerceivedBox(c,(H[1],H[0],H[2]),yaw-math.pi/2)}
for k,b in reps.items():
    ids=pm.load_obstacles([b]); d=pm.data_at(q)
    print(k,[(round(mujoco.mj_geomDistance(m,d,g,ids[0],1.0,ft),3),round(brute(d,g,b),3)) for g in pm.hand_geoms['right'][:5]], m.geom_quat[ids[0]], m.geom_size[ids[0]])
